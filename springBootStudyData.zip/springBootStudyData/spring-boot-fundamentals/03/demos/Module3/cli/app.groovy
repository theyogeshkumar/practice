@RestController
class app{
    @RequestMapping("/")
    String home() {
        "Hello Pluralsight!"
    }
}
