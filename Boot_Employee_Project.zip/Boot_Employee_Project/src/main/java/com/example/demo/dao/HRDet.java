package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.HR;

public interface HRDet extends CrudRepository<HR, Integer>{

}
