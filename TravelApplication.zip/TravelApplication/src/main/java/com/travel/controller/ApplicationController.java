package com.travel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.travel.entity.Country;
import com.travel.entity.CountryRepo;

@Controller
public class ApplicationController {

	@Autowired
	private CountryRepo countryRepo;
	
	@RequestMapping("/")
	public String homePage() {
		return "Interface";

	}
	@RequestMapping("/admin")
	public String adminPage() {
		return "admin";

	}
	@RequestMapping("/customer")
	public String customerPage() {
		return "customer";

	}
	
	@RequestMapping(path="/adminlogin",method=RequestMethod.POST)
	public String adminLogin(@RequestParam("username") 	String uname,@RequestParam("password") String pwd) {
		if(uname.equals("admin") && pwd.equals("admin@123"))
			return "adminmodule";
		else
			return "adminloginunsuccess";
	}
	
	@RequestMapping("/AddCountry")
	public String addCountry() {
	      return "AddCountry";
	}
	
	@RequestMapping("/addcountry")
	public ModelAndView createProduct(@RequestParam("countryName") String countryName, @RequestParam("cityName") String cityName,
	@RequestParam("hotelName") String hotelName, @RequestParam("hotelDesc") String hotelDesc) {


	ModelAndView mv = new ModelAndView();
	mv.addObject("countryName", countryName);
	mv.addObject("cityName", cityName);
	mv.addObject("hotelName", hotelName);
	mv.addObject("hotelDesc", hotelDesc);
	mv.setViewName("AddSuccess");

	//insert data in database
	Country cntr = new Country();
	cntr.setCountryName(countryName);
	cntr.setCityName(cityName);
	cntr.setHotelName(hotelName);
	cntr.setHotelDesc(hotelDesc);
	countryRepo.save(cntr);
	return mv;

	}	
}