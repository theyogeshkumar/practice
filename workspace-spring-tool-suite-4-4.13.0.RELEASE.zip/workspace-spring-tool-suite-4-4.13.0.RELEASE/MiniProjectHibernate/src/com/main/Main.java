package com.main;

import com.controller.AdminController;

public class Main {

	public static void main(String[] args) {
		AdminController admin=new AdminController();
		admin.admin();

	}

}
