package com.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CustomerDetails")
public class Customer {
	@Id
	@GeneratedValue
	private int cust_id;
	private String cust_name;
	private String cust_gender;
	private int cust_age;
	private String cust_address;
	private long cust_phone_no;
	private String cust_email;
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCust_gender() {
		return cust_gender;
	}
	public void setCust_gender(String cust_gender) {
		this.cust_gender = cust_gender;
	}
	public int getCust_age() {
		return cust_age;
	}
	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}
	public String getCust_address() {
		return cust_address;
	}
	public void setCust_address(String cust_address) {
		this.cust_address = cust_address;
	}
	public long getCust_phone_no() {
		return cust_phone_no;
	}
	public void setCust_phone_no(long cust_phone_no) {
		this.cust_phone_no = cust_phone_no;
	}
	public String getCust_email() {
		return cust_email;
	}
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	
	
}
