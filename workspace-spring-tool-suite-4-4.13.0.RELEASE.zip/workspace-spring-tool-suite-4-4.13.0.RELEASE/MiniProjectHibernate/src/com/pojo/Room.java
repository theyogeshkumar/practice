package com.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="RoomDetails")
public class Room {
	@Id
	@GeneratedValue
	private int room_no;
	private String room_type;
	private int room_fare;
	private String ac_available;
	private String room_available;
	
	
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getRoom_fare() {
		return room_fare;
	}
	public void setRoom_fare(int room_fare) {
		this.room_fare = room_fare;
	}
	public String getAc_available() {
		return ac_available;
	}
	public void setAc_available(String ac_available) {
		this.ac_available = ac_available;
	}
	public String getRoom_available() {
		return room_available;
	}
	public void setRoom_available(String room_available) {
		this.room_available = room_available;
	}
	
	
	
	
	
	
	
	
	
}
