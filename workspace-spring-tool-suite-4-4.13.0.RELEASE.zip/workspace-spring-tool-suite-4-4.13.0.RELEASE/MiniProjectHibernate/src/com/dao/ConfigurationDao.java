package com.dao;

import org.hibernate.cfg.Configuration;

public class ConfigurationDao {

	public static Configuration getConf() {
		Configuration conf= new Configuration();
		conf.configure("customer.cfg.xml");
		return conf;
	}
}
