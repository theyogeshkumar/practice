package com.controller;

import java.util.Scanner;

import com.model.CustomerCrudOperation;


public class CustomerController {
	Scanner sc= new Scanner (System.in);
//	CustomerCrudOperation cust_crud=new CustomerCrudOperation();
	public void customerOperations() {
		System.out.println("Select the Customer operation");
		System.out.println();
		System.out.println("1. Add Customer�s Data");
		System.out.println("2. Update Customer�s Data");
		System.out.println("3. Delete Customer�s information using Id");
		System.out.println("4. Display all customer�s information");
		System.out.println("5. Display Single Customer�s information by providing customer Id.");
		int input =sc.nextInt();
		switch (input) {
		case 1:
			CustomerCrudOperation.addCustomer();
			break;
		case 2:
			CustomerCrudOperation.updateCustomer();
			break;
		case 3:
			CustomerCrudOperation.deleteCustomer();
			break;
		case 4:
			CustomerCrudOperation.displayCustomer();
			break;
		case 5:
			CustomerCrudOperation.displayCustomerWithId();
			break;
		default:customerOperations();
			break;
		}
	}
}
