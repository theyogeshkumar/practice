package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Room;

public class RoomController {
	static Scanner input= new Scanner(System.in);
	static Room room=new Room();
	
	public static void room() {
		System.out.println("Select Room Admin operations");
		System.out.println("1. Add Room Details");
		System.out.println("2. Display Room Details");
		System.out.println("3. Update Room Details");
		int key=input.nextInt();
		switch (key) {
		case 1:
			addRoomDetails();
			break;
		case 2:
			addRoomDetails();
			break;
		case 3:
			updateRoomDetails();
			break;

		default:System.exit(0);
			break;
		}
	}
	//Function to add room details
	public static void addRoomDetails() {
		//configuration
				Configuration conf=new Configuration();
				conf.configure();
				SessionFactory sf = conf.buildSessionFactory();
				Session session = sf.openSession();
				Transaction tran = session.beginTransaction();
				
				//operations
				System.out.println("Enter the Type of Room");
				String room_type = input.next();
				room.setRoom_type(room_type);
				System.out.println("Enter the Fare of Room");
				int room_fare=input.nextInt();
				room.setRoom_fare(room_fare);
				System.out.println("Ac Available in the Room Or Not");
				String ac_available=input.next();
				room.setAc_available(ac_available);
				System.out.println("Room Available Or Not");
				String room_available = input.next();
				room.setRoom_available(room_available);
				
				session.save(room);
				tran.commit();
				session.close();
				System.out.println("Details Added Successfully");
	}
	
	//function to display room details on console
		public static void displayRoomDetails() {
			Configuration conf=new Configuration();
			conf.configure();
			SessionFactory sf = conf.buildSessionFactory();
			Session session = sf.openSession();
			Transaction tran = session.beginTransaction();
			TypedQuery qr = session.createQuery("from Room"); 
			List<Room> rooms = qr.getResultList();
			Iterator<Room> itr = rooms.iterator();
			while(itr.hasNext()) {
				Room room = itr.next();
				System.out.println("Room NO.="+room.getRoom_no()
				+" Type = "+room.getRoom_type()+" Fare ="+room.getRoom_fare()+" Ac Available ="+room.getAc_available()
				+" Room Available ="+room.getRoom_available());
			}
			tran.commit();
			session.close();

		}
		
		//Function to update Customer data in dataBase
		public static void updateRoomDetails() {
			Configuration conf=new Configuration();
			conf.configure();
			SessionFactory sf = conf.buildSessionFactory();
			Session session = sf.openSession();
			Transaction tran = session.beginTransaction();
			//here we do not use table and we use persistent class
			System.out.println("Enter the ID of Room");
			int room_no = input.nextInt();
			System.out.println("Enter the type of Room");
			String room_type = input.next();
			room.setRoom_type(room_type);
			System.out.println("Enter the Fare of Room");
			int room_fare=input.nextInt();
			room.setRoom_fare(room_fare);
			Query qr = session.createQuery("update Room set room_type=:t,room_fare=:f where room_no=:i");
			
			qr.setParameter("t", room_type);
			qr.setParameter("f", room_fare);
			qr.setParameter("i", room_no);
			int row = qr.executeUpdate();
			System.out.println(row + " Rows Updated");
			tran.commit();
			session.close();

		}
}
