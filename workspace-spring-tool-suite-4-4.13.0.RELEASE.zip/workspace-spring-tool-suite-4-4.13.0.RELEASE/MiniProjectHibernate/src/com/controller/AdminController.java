package com.controller;

import java.util.Scanner;

import com.model.Booking;

public class AdminController {
	Scanner sc= new Scanner (System.in);
	CustomerController cust_controller=new CustomerController();
	public void admin() {
		System.out.println("Welome to Our Hotel Management System");
		System.out.println();
		System.out.println("Select the operation ot do.");
		System.out.println("1. Customer Operation.");
		System.out.println("2. Room Operation.");
		System.out.println("3. Booking For Customer");
		System.out.println("0. Exit.");
		int input=sc.nextInt();
		switch (input) {
		case 1:
			cust_controller.customerOperations();
			break;
		case 2:
			RoomController.room();
			break;
		case 3:
			Booking.addBookingDetails();
			break;
		default:System.exit(0);
			break;
		}
	}
}
