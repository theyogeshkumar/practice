package com.model;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Customer;
//The Admin-customerOpertions class
public class CustomerCrudOperation {
	static Customer customer=new Customer();
	static Scanner input= new Scanner(System.in);
	
	//Function to Add Customer in dataBase
	public static void addCustomer() {
		//configuration
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		
		//operations
		System.out.println("Enter the Name of Customer");
		String cust_name = input.next();
		customer.setCust_name(cust_name);
		System.out.println("Enter the gender of Customer");
		String cust_gender=input.next();
		customer.setCust_gender(cust_gender);
		System.out.println("Enter the Age of Customer");
		int cust_age=input.nextInt();
		customer.setCust_age(cust_age);
		System.out.println("Enter the Address of Customer");
		String cust_address = input.next();
		customer.setCust_address(cust_address);
		System.out.println("Enter the Phone Number of Customer");
		long cust_phone=input.nextLong();
		customer.setCust_phone_no(cust_phone);
		System.out.println("Enter the Email of Customer");
		String cust_email=input.next();
		customer.setCust_email(cust_email);
		session.save(customer);
		tran.commit();
		session.close();
		System.out.println("Customer Added Successfully");

	}
	
	//Function to update Customer data in dataBase
	public static void updateCustomer() {
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		//here we do not use table and we use persistent class
		System.out.println("Enter the ID of Customer");
		int cust_id = input.nextInt();
		System.out.println("Enter the Name of Customer");
		String cust_name = input.next();
		customer.setCust_name(cust_name);
		System.out.println("Enter the gender of Customer");
		String cust_gender=input.next();
		customer.setCust_gender(cust_gender);
		System.out.println("Enter the Age of Customer");
		int cust_age=input.nextInt();
		customer.setCust_age(cust_age);
		System.out.println("Enter the Address of Customer");
		String cust_address = input.next();
		customer.setCust_address(cust_address);
		System.out.println("Enter the Phone Number of Customer");
		long cust_phone=input.nextLong();
		customer.setCust_phone_no(cust_phone);
		System.out.println("Enter the Email of Customer");
		String cust_email=input.next();
		customer.setCust_email(cust_email);
		Query qr = session.createQuery("update Customer set cust_name=:n,cust_gender=:g,cust_age=:a,cust_address=:ad,cust_phone_no=:p,cust_email=:e where cust_id=:i");
		
		qr.setParameter("n", cust_name);
		qr.setParameter("g", cust_gender);
		qr.setParameter("a", cust_age);
		qr.setParameter("ad", cust_address);
		qr.setParameter("p", cust_phone);
		qr.setParameter("e", cust_email);
		qr.setParameter("i", cust_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		tran.commit();
		session.close();

	}
	
	//Function to delete the customer from the database
	public static void deleteCustomer() {
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		//
		
		System.out.println("Enter the ID of Customer");
		int cust_id = input.nextInt();
		Query qr = session.createQuery("delete from Customer where cust_id=:i");
		qr.setParameter("i", cust_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		tran.commit();
		session.close();

	}
	
	//function to display customer details on console
	public static void displayCustomer() {
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		System.out.println("Enter the ID of Customer");
		int cust_id = input.nextInt();
		TypedQuery qr = session.createQuery("from Customer"); 
		List<Customer> customers = qr.getResultList();
		Iterator<Customer> itr = customers.iterator();
		while(itr.hasNext()) {
			Customer cust = itr.next();
			System.out.println("Customer ID="+cust.getCust_id()
			+" Name = "+cust.getCust_name()+" Gender ="+cust.getCust_gender()+" Age ="+cust.getCust_age()
			+" Address ="+cust.getCust_address()+" Phone Number ="+cust.getCust_phone_no()+" Email ="+cust.getCust_email());
		}
		tran.commit();
		session.close();

	}
	
	
	//function to display customer details on console with cust_id
		public static void displayCustomerWithId() {
			Configuration conf=new Configuration();
			conf.configure();
			SessionFactory sf = conf.buildSessionFactory();
			Session session = sf.openSession();
			Transaction tran = session.beginTransaction();
			System.out.println("Enter the ID of Customer");
			int cust_id = input.nextInt();
			TypedQuery qr = session.createQuery("from Customer where cust_id=:i"); 
			qr.setParameter("i", cust_id);
			List<Customer> customers = qr.getResultList();
			Iterator<Customer> itr = customers.iterator();
			while(itr.hasNext()) {
				Customer cust = itr.next();
				System.out.println("Customer ID="+cust.getCust_id()
				+" Name = "+cust.getCust_name()+" Gender ="+cust.getCust_gender()+" Age ="+cust.getCust_age()
				+" Address ="+cust.getCust_address()+" Phone Number ="+cust.getCust_phone_no()+" Email ="+cust.getCust_email());
			}
			tran.commit();
			session.close();

		}
	
	
	
	
}
