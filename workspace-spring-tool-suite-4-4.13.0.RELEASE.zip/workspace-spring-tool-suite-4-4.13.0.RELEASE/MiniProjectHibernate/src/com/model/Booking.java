package com.model;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.RoomBooking;

public class Booking {
	static Scanner input=new Scanner (System.in);
    static 	RoomBooking book_room=new RoomBooking();
	public static void addBookingDetails() {
		//configuration
				Configuration conf=new Configuration();
				conf.configure();
				SessionFactory sf = conf.buildSessionFactory();
				Session session = sf.openSession();
				Transaction tran = session.beginTransaction();
				
				//operations
				System.out.println("Enter Booking Date");
				String booking_date =input.next();
				book_room.setBooking_date(booking_date);
				System.out.println("Enter the Customer Name");
				String cust_name=input.next();
				book_room.setCust_name(cust_name);
				System.out.println("Enter Customer Phone Number");
				long cust_phone=input.nextLong();
				book_room.setCust_phone(cust_phone);
				System.out.println("Enter Room Number");
				int room_no = input.nextInt();
				book_room.setRoom_no(room_no);
				System.out.println("Enter the No. of Days To Book Room");
				int days=input.nextInt();
				book_room.setDays(days);
				System.out.println("Enter The fare of the Room");
				double fare=input.nextDouble();
				book_room.setFare(fare);
				
				session.save(book_room);
				tran.commit();
				session.close();
				System.out.println("Details Added Successfully");
				
				
				System.out.println();
				double bill=(fare*days);
				System.out.println("The Total Bill of the booking is: "+bill);
				
	}
}
