package com.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="DoctorsDetails")
public class Doctors {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int doctor_id;
	private String doctor_name;
	private String doctor_specialty;
	private String doctor_address;
	private long doctor_phone;
	@OneToOne(
		    mappedBy = "post",
		    orphanRemoval = true,
		    cascade = CascadeType.ALL)
	private Patients patient;

	public int getDoctor_id() {
		return doctor_id;
	}

	public void setDoctor_id(int doctor_id) {
		this.doctor_id = doctor_id;
	}

	public String getDoctor_name() {
		return doctor_name;
	}

	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}

	public String getDoctor_specialty() {
		return doctor_specialty;
	}

	public void setDoctor_specialty(String doctor_specialty) {
		this.doctor_specialty = doctor_specialty;
	}

	public String getDoctor_address() {
		return doctor_address;
	}

	public void setDoctor_address(String doctor_address) {
		this.doctor_address = doctor_address;
	}

	public long getDoctor_phone() {
		return doctor_phone;
	}

	public void setDoctor_phone(long doctor_phone) {
		this.doctor_phone = doctor_phone;
	}

	public Patients getPatient() {
		return patient;
	}

	public void setPatient(Patients patient) {
		this.patient = patient;
	}
	
	
}
