package com.pojo;

import java.util.Scanner;

import com.controller.DoctorController;
import com.controller.PatientController;

public class App 
{
	static Scanner sc= new Scanner(System.in);
	static Patients patient=new Patients();
	static Doctors doctor= new Doctors();
    public static void main( String[] args )
    {
        System.out.println("Welcome To ABC Hospital");
        System.out.println();
        System.out.println("Enter The Choice");
        System.out.println("1. Patients");
        System.out.println("2. Doctors");
        System.out.println("0. Exit");
        int key=sc.nextInt();
        switch (key) {
		case 1:
			PatientController.addPatient();
			DoctorController.addDoctor();
			patient.setDoctor(doctor);
			doctor.setPatient(patient);
			break;
		case 2:
			
			break;
		default:System.exit(0);
			break;
		}
    }
}
