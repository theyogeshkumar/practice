package com.controller;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Doctors;
import com.pojo.Patients;

public class DoctorController {

	static Scanner sc= new Scanner(System.in);
	public static void addDoctor() {
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf=conf.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tran=session.beginTransaction();
		Doctors doct= new Doctors();
		System.out.println("Enter The Name Of Doctor");
		String doctor_name=sc.next();
		doct.setDoctor_name(doctor_name);
		System.out.println("Enter The Specialty Of Doctor");
		String doctor_specialty=sc.next();
		doct.setDoctor_specialty(doctor_specialty);
		System.out.println("Enter The Address Of Doctor");
		String doctor_address=sc.next();
		doct.setDoctor_address(doctor_address);
		System.out.println("Enter The Phone Number Of Doctor");
		long doctor_phone=sc.nextLong();
		doct.setDoctor_phone(doctor_phone);
		
		
		
		
		
		
		session.save(doct);
		tran.commit();
		session.close();
		System.out.println(" Doctor Added to Database");
		
	}
}
