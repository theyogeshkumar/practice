package com.controller;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Doctors;
import com.pojo.Patients;

public class PatientController {

	static Scanner sc= new Scanner(System.in);
	public static void addPatient() {
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf=conf.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tran=session.beginTransaction();
		Patients pat= new Patients();
		System.out.println("Enter The Name Of Patient");
		String patient_name=sc.next();
		pat.setPatient_name(patient_name);
		System.out.println("Enter The Problem,Symptoms Or Disease Of Patient");
		String patient_problem=sc.next();
		pat.setPatient_name(patient_problem);
		System.out.println("Enter The Age Of Patient");
		int patient_age=sc.nextInt();
		pat.setPatient_age(patient_age);
		System.out.println("Enter The Address Of Patient");
		String patient_adress=sc.next();
		pat.setPatient_address(patient_adress);
		System.out.println("Enter The Phone Number Of Patient");
		long patient_phone=sc.nextLong();
		pat.setPatient_phone(patient_phone);
		
		
		
		
		
		
		session.save(pat);
		tran.commit();
		session.close();
		System.out.println(" Patient Added to Database");
		
	}
}
