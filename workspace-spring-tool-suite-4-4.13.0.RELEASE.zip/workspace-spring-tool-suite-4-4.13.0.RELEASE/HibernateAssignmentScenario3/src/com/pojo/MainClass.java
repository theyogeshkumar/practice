package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration conf= new Configuration();
		conf.configure();
		SessionFactory sf=conf.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tran=session.beginTransaction();
		Patients obj=new Patients();
		obj.setPatient_name("Pushpa");
		obj.setAge(33);
		OpdPatients obj1=new OpdPatients();
		obj1.setAge(29);
		obj1.setPatient_name("Suruli");
		obj1.setSymptoms("Stomachache");
		obj1.setIllness("thyphoid");
		AdmittedPatients obj2=new AdmittedPatients();
		obj2.setAge(24);
		obj2.setPatient_name("Jagame");
		obj2.setBed_number(153);
		obj2.setAdmission_date("29/1/2022");
		obj2.setDoctor_name("Bhavika Kalra");
		obj2.setFile_number(007);
		session.save(obj);
		session.save(obj1);
		session.save(obj2);
		tran.commit();
		session.close();
		System.out.println("added Successfully.");
		
		
	}

}
