package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration conf= new Configuration();
		conf.configure();
		SessionFactory sf=conf.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tran=session.beginTransaction();
		Patients obj=new Patients();
		obj.setPatient_name("John Cena");
		obj.setAge(43);
		OpdPatients obj1=new OpdPatients();
		obj1.setAge(23);
		obj1.setPatient_name("Rakshit");
		obj1.setSymptoms("cold");
		obj1.setIllness("Running Nose");
		AdmittedPatients obj2=new AdmittedPatients();
		obj2.setAge(22);
		obj2.setPatient_name("Bhuvan");
		obj2.setBed_number(142);
		obj2.setAdmission_date("10/1/2022");
		obj2.setDoctor_name("Priyanka Sisodia");
		obj2.setFile_number(123);
		session.save(obj);
		session.save(obj1);
		session.save(obj2);
		tran.commit();
		session.close();
		System.out.println("added Successfully.");
		
		
	}

}
