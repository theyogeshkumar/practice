package admin;

public class Admin {

	public static void admin() {
		System.out.println("----------Admin Operations----------");
		System.out.println();
		System.out.println("1. Add Product");
		System.out.println("2. Display Product");
		System.out.println("3. Delete Product");
		System.out.println("4. Update Product");
		System.out.println("5. Generate Product Report");
		System.out.println("6. Display Customer Details");
		System.out.println("7. Delete Customer");
		System.out.println("8. Generate Customer Report");
		System.out.println("0. Exit");
	}
}
