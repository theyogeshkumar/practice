package customer;

import java.util.Scanner;


public class Customer {

	public static void customer() {
		Scanner sc= new Scanner(System.in);
		System.out.println("----------Start Shopping----------");
		System.out.println();
		System.out.println("1. Mobile");
		System.out.println("2. Laptop");
		System.out.println("3. Furniture");
		System.out.println("4. Home Appliances");
		System.out.println("5. Fashion");
		System.out.println("0. Exit");
		
		
		int input=sc.nextInt();
		switch (input) {
		case 1:
			CustomerProduct.mobile();
			break;
		case 2:
			CustomerProduct.laptop();
			break;
		case 3:
			CustomerProduct.furniture();
			break;
		case 4:
			CustomerProduct.homeAppliances();
			break;
		case 5:
			CustomerProduct.fashion();
			break;
		}
		
		
	}
}
