package customer;

import java.util.Scanner;

public class CustomerProduct {

	//fashion products.
		public static void fashion() {
			Scanner sc= new Scanner(System.in);
			System.out.println("         Main Menu       ");
			System.out.println();
			System.out.println("1.saree     -        2000 ");
			System.out.println("2.Kurta     -        3000 ");
			System.out.println("3.Lehnga    -        9000 ");
			System.out.println("4.jeans     -        1000 ");
			System.out.println("5.Top's     -         800 ");
			System.out.println("6.Jacket's  -        2600 ");
			System.out.println("7.Exit                   ");
			System.out.println();
			
			System.out.println("Select The Product To Buy");
			int product=sc.nextInt();
			switch(product) {
			case 1:
				product = 2000;
				System.out.println("1.saree             2000 rs.");
				break;
			case 2:
				product = 3000;
				System.out.println("2.Kurta     -        3000 rs.");
				break;
			case 3:
				product = 9000;
				System.out.println("3.Lehnga    -        9000 rs.");
				break;
			case 4:
				product = 1000;
				System.out.println("4.jeans     -        1000 rs.");
				break;
			case 5:
				product = 800;
				System.out.println("5.Top's     -         800 rs.");
				break;
			case 6:
				product = 2600;
				System.out.println("6.Jacket's  -        2600 rs.");
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
			bill(product);
		}
		
		//mobile products
		public static void mobile() {
			Scanner sc= new Scanner(System.in);
			System.out.println("         Main Menu       ");
			System.out.println();
			System.out.println("1.Iphone       -        120000 ");
			System.out.println("2.Realme       -        23000 ");
			System.out.println("3.Oppo         -        19000 ");
			System.out.println("4.Vivo         -        15000 ");
			System.out.println("5.Lava         -        9000 ");
			System.out.println("6.Micromax     -        9600 ");
			System.out.println("7.Exit                   ");
			System.out.println();
			
			System.out.println("Select The Product To Buy");
			int product=sc.nextInt();
			switch(product) {
			case 1:
				product = 120000;
				System.out.println("1.Iphone       -        120000 ");
				break;
			case 2:
				product = 23000;
				System.out.println("2.Realme       -        23000 ");
				break;
			case 3:
				product = 19000;
				System.out.println("3.Oppo         -        19000 ");
				break;
			case 4:
				product = 15000;
				System.out.println("4.Vivo         -        15000 ");
				break;
			case 5:
				product = 9000;
				System.out.println("5.Lava         -        9000 ");
				break;
			case 6:
				product = 9600;
				System.out.println("6.Micromax     -        9600 ");
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
			
			bill(product);
		}
		
		//furniture
		public static void furniture() {
			Scanner sc= new Scanner(System.in);
			System.out.println("         Main Menu       ");
			System.out.println();
			System.out.println("1.Sofa            -        20000 ");
			System.out.println("2.Bed             -        30000 ");
			System.out.println("3.Table           -        9000 ");
			System.out.println("4.Chair           -        1500 ");
			System.out.println("5.Almirah         -        19000 ");
			System.out.println("6.dressing Table  -        9600 ");
			System.out.println("7.Exit                   ");
			System.out.println();
			
			System.out.println("Select The Product To Buy");
			int product=sc.nextInt();
			switch(product) {
			case 1:
				product = 20000;
				System.out.println("1.Sofa            -        20000 ");
				break;
			case 2:
				product = 30000;
				System.out.println("2.Bed             -        30000 ");
				break;
			case 3:
				product = 9000;
				System.out.println("3.Table           -        9000 ");
				break;
			case 4:
				product = 1500;
				System.out.println("4.Chair           -        1500 ");
				break;
			case 5:
				product = 19000;
				System.out.println("5.Almirah         -        19000 ");
				break;
			case 6:
				product = 9600;
				System.out.println("6.dressing Table  -        9600 ");
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
			bill(product);
		}
		
			//HomeAppliances
		public static void homeAppliances() {
			Scanner sc= new Scanner(System.in);
			System.out.println("         Main Menu       ");
			System.out.println();
			System.out.println("1.AC                -        40000 ");
			System.out.println("2.Washing machine   -        23000 ");
			System.out.println("3.Microwave Oven    -        7000 ");
			System.out.println("4.Refrigerator      -        25000 ");
			System.out.println("5.Smart Tv          -        19000 ");
			System.out.println("6.DishWasher        -        19600 ");
			System.out.println("7.Exit                   ");
			System.out.println();
			
			System.out.println("Select The Product To Buy");
			int product=sc.nextInt();
			switch(product) {
			case 1:
				product = 40000;
				System.out.println("1.AC                -        40000 ");
				break;
			case 2:
				product = 23000;
				System.out.println("2.Washing machine   -        23000 ");
				break;
			case 3:
				product = 7000;
				System.out.println("3.Microwave Oven    -        7000 ");
				break;
			case 4:
				product = 25000;
				System.out.println("4.Refrigerator      -        25000 ");
				break;
			case 5:
				product = 19000;
				System.out.println("5.Smart Tv          -        19000 ");
				break;
			case 6:
				product = 19600;
				System.out.println("6.DishWasher        -        19600 ");
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
			
			bill(product);
		}
		
		//Laptop
		public static void laptop() {
			Scanner sc= new Scanner(System.in);
			System.out.println("         Main Menu       ");
			System.out.println();
			System.out.println("1.Lenevo    -        70000 ");
			System.out.println("2.HP        -        63000 ");
			System.out.println("3.Dell      -        80000 ");
			System.out.println("4.MSI       -        55000 ");
			System.out.println("5.Asus      -        59000 ");
			System.out.println("6.Acer      -        69600 ");
			System.out.println("7.Exit                   ");
			System.out.println();
			
			System.out.println("Select The Product To Buy");
			int product=sc.nextInt();
			switch(product) {
			case 1:
				product = 70000;
				System.out.println("1.Lenevo    -        70000 ");
				break;
			case 2:
				product = 63000;
				System.out.println("2.HP        -        63000 ");
				break;
			case 3:
				product = 80000;
				System.out.println("3.Dell      -        80000 ");
				break;
			case 4:
				product = 55000;
				System.out.println("4.MSI       -        55000 ");
				break;
			case 5:
				product = 59000;
				System.out.println("5.Asus      -        59000 ");
				break;
			case 6:
				product = 69600;
				System.out.println("6.Acer      -        69600 ");
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
			bill(product);
		}
		
		
		
		
		static void bill(int product) {
			Scanner sc= new Scanner(System.in);
			
			System.out.println("Enter The Quantity You Want To Buy");
			int quantity=sc.nextInt();
			double bill=product*quantity;
			System.out.println("Total Bill: "+bill);
		}

	
}
