package product;


public class Product {
	private int product_id;
	private int product_name;
	private int product_price;
	private int product_desc;
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getProduct_name() {
		return product_name;
	}
	public void setProduct_name(int product_name) {
		this.product_name = product_name;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public int getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(int product_desc) {
		this.product_desc = product_desc;
	}
	public Product(int product_id, int product_name, int product_price, int product_desc) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_desc = product_desc;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
