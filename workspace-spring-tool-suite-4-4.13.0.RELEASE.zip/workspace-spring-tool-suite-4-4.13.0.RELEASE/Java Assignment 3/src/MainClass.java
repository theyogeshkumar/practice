import java.util.Scanner;

import login.LogIn;

public class MainClass {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		LogIn new_login= new LogIn();
		new_login.welcome();
		
	}
	
//	static void welcome() {
//		Scanner sc= new Scanner(System.in);
//		System.out.println("----------Welcome To ABC Store----------");
//		System.out.println();
//		System.out.println("Select Your Role.");
//		System.out.println();
//		System.out.println("Press 1 for Admin.");
//		System.out.println("Press 2 for Customer.");
//		System.out.println("Press 0 for Exit.");
//		
//		int input=sc.nextInt();
//		if(input==1) {
//			logIn();
//			admin();
//		}else if(input==2) {
//			logIn();
//			customer();
//		}else {
//			System.exit(0);
//		}
//		
//	}
//	
//	static void logIn() {
//		Scanner sc= new Scanner(System.in);
//		System.out.println("Enter Username.  (use 'yogesh' for Demo)");
//		String username=sc.next();
//		System.out.println("Enter Password.  (use '12345' for Demo)");
//		String pass= sc.next();
//		
//		if(username.equals("yogesh") && pass.equals("12345")) {
//			System.out.println("Login Successful.");
//			System.out.println();
//		}else {
//			System.out.println("Wrong Credentials.");
//			System.out.println();
//			logIn();
//			
//		}
//	}
//	
//	static void admin() {
//		System.out.println("----------Admin Operations----------");
//		System.out.println();
//		System.out.println("1. Add Product");
//		System.out.println("2. Display Product");
//		System.out.println("3. Delete Product");
//		System.out.println("4. Update Product");
//		System.out.println("5. Generate Product Report");
//		System.out.println("6. Display Customer Details");
//		System.out.println("7. Delete Customer");
//		System.out.println("8. Generate Customer Report");
//		System.out.println("0. Exit");
//	}
//	
//	static void customer() {
//		Scanner sc= new Scanner(System.in);
//		System.out.println("----------Start Shopping----------");
//		System.out.println();
//		System.out.println("1. Mobile");
//		System.out.println("2. Laptop");
//		System.out.println("3. Furniture");
//		System.out.println("4. Home Appliances");
//		System.out.println("5. Electronics");
//		System.out.println("6. Get Invoice");
//		System.out.println("0. Exit");
//		
//		
//		int input=sc.nextInt();
//		switch (input) {
//		case 1:
//			System.out.println("1");
//			break;
//		case 2:
//			System.out.println("2");
//			break;
//		case 3:
//			System.out.println("3");
//			break;
//		case 4:
//			System.out.println("4");
//			break;
//		}
//		
//	}

}
