package pojo;

public class CustomerDetails {

}
