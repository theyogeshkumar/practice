package dataAccessObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import product.Product;

public class ProductDaoImpl  implements ProductDao{
	
	Scanner input= new Scanner(System.in);
	
//	object for product class
	Product prod=new Product();
	
	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=ProductManagementSystem;user=sa;password=Password_123","sa","Password_123");
//			System.out.println("Connected");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	@Override
	public void insertProduct() {
		System.out.println("Enter The Product Name:");
		String prod_name=input.next();
		prod.setProd_name(prod_name);
		System.out.println("Enter The Product Price");
		float prod_price=input.nextFloat();
		prod.setProd_price(prod_price);
	
		Connection con=getConnection();
		
		try {
			PreparedStatement stmt=con.prepareStatement("insert into Product values(?,?)");
			stmt.setString(1, prod.getProd_name());
			stmt.setFloat(2, prod.getProd_price());
			stmt.executeUpdate();
			System.out.println("Product Added Successfully.");
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		
		
	}

	@Override
	public void deleteProduct() {
		System.out.println("Enter the Product Id to Remove the Product");
		int prod_id=input.nextInt();
		prod.setProd_id(prod_id);
		
		Connection con=getConnection();
		
		try {
			PreparedStatement stmt=con.prepareStatement("delete from Product where prod_id=?");
			stmt.setInt(1,prod.getProd_id());
			stmt.executeUpdate();
			con.close();
			System.out.println("Product Deleted Successfully");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public void updateProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Product> getProduct() {
		List<Product> list=new ArrayList<Product>();
		
		Connection con=getConnection();
		
		try {
			
			Statement stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Product") ;
			while(rs.next()) {
//				System.out.println("Product ID- "+rs.getInt(1)+
//						" Product Name- '"+rs.getString(2)+" 'Product Price- "+rs.getFloat(3));
//				System.out.println();
				prod=new Product(rs.getInt(1),rs.getString(2),rs.getFloat(3));
				list.add(prod);
			}
	
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}

}
