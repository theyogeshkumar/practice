package dataAccessObject;

import java.util.List;
import product.Product;

public interface ProductDao {

	public void insertProduct();
	public void deleteProduct();
	public void updateProduct();
	public List<Product> getProduct();
}
