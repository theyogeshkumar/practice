import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dataAccessObject.ProductDaoImpl;
import product.Product;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Connection con=ProductDaoImpl.getConnection();
		ProductDaoImpl obj=new  ProductDaoImpl();
		List<Product> li=obj.getProduct();
		for (Iterator iterator = li.iterator(); iterator.hasNext();) {
			Product product = (Product) iterator.next();
			System.out.println("Product Id = "+product.getProd_id()+" Product Name= "+product.getProd_name()+" Product Price= "+product.getProd_price());
		}
		
		
	}

}
