package com.pojo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="OpdPatients1")
@AttributeOverrides({
	@AttributeOverride(name="registration_number",column=@Column(name="registration_number")),
	@AttributeOverride(name="patient_name",column=@Column(name="patient_name")),
	@AttributeOverride(name="age",column=@Column(name="age")),
})
public class OpdPatients extends Patients{

	private String symptoms;
	private String illness;
	public String getSymptoms() {
		return symptoms;
	}
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}
	public String getIllness() {
		return illness;
	}
	public void setIllness(String illness) {
		this.illness = illness;
	}
	
	
}
