package com.pojo;


import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="AdmittedPatients1")
@AttributeOverrides({
	@AttributeOverride(name="registration_number",column=@Column(name="registration_number")),
	@AttributeOverride(name="patient_name",column=@Column(name="patient_name")),
	@AttributeOverride(name="age",column=@Column(name="age")),
})
public class AdmittedPatients extends Patients {

	private int bed_number;
	private String admission_date;
	private String doctor_name;
	private int file_number;
	
	public int getBed_number() {
		return bed_number;
	}
	public void setBed_number(int bed_number) {
		this.bed_number = bed_number;
	}
	public String getAdmission_date() {
		return admission_date;
	}
	public void setAdmission_date(String admission_date) {
		this.admission_date = admission_date;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public int getFile_number() {
		return file_number;
	}
	public void setFile_number(int file_number) {
		this.file_number = file_number;
	}
	
	
	
}
