package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration conf= new Configuration();
		conf.configure();
		SessionFactory sf=conf.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tran=session.beginTransaction();
		Patients patient=new Patients();
		patient.setPatient_name("Vikas");
		patient.setAge(23);
		OpdPatients opd=new OpdPatients();
		opd.setAge(33);
		opd.setPatient_name("bimal");
		opd.setSymptoms("fever");
		opd.setIllness("loosemotion");
		AdmittedPatients admitted=new AdmittedPatients();
		admitted.setAge(23);
		admitted.setPatient_name("sumit");
		admitted.setBed_number(214);
		admitted.setAdmission_date("09/5/2022");
		admitted.setDoctor_name("sonu sharma");
		admitted.setFile_number(987);
		session.save(patient);
		session.save(opd);
		session.save(admitted);
		tran.commit();
		session.close();
		System.out.println("added Successfully.");
		
		
	}

}
