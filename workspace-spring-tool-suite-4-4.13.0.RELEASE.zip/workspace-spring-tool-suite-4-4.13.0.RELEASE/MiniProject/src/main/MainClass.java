package main;

import java.io.IOException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		Scanner sc= new Scanner(System.in);
		LogIn new_login= new LogIn();
		new_login.welcome();
		
	}
}
