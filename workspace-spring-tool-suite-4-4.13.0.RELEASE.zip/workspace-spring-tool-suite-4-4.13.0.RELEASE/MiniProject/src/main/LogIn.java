package main;

import java.io.IOException;
import java.util.Scanner;
import admin.Admin;
import customer.Customer;

public class LogIn {
	
	 public  void welcome() throws ClassNotFoundException, IOException {
		Scanner sc= new Scanner(System.in);
		System.out.println("----------Welcome To ABC Store----------");
		System.out.println();
		System.out.println("Select Your Role.");
		System.out.println();
		System.out.println("Press 1 for Admin.");
		System.out.println("Press 2 for Customer.");
		System.out.println("Press 0 for Exit.");
		
		int input=sc.nextInt();
		if(input==1) {
			logIn();
			Admin.admin();
		}else if(input==2) {
			logIn();
			Customer.customer();
			
		}else {
			System.exit(0);
		}
		
	}
	
	 static void logIn() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Username.  (use 'yogesh' for Demo)");
		String username=sc.next();
		System.out.println("Enter Password.  (use '12345' for Demo)");
		String pass= sc.next();
		
		if(username.equals("yogesh") && pass.equals("12345")) {
			System.out.println("Login Successful.");
			System.out.println();
		}else {
			System.out.println("Wrong Credentials.");
			System.out.println();
			logIn();
			
		}
	}
	 
}
