package admin;

import java.io.IOException;
import java.util.Scanner;

import customer.CustomerProduct;
import product.ProductList;

public class Admin {

	public static void admin() throws ClassNotFoundException, IOException {
		Scanner sc= new Scanner(System.in);
		System.out.println("----------Admin Operations----------");
		System.out.println();
		System.out.println("1. Add Product");
		System.out.println("2. Display Product");
		System.out.println("3. Delete Product");
		System.out.println("4. Update Product");
		System.out.println("5. Generate Product Report");
		System.out.println("6. Display Customer Details");
		System.out.println("7. Delete Customer");
		System.out.println("8. Generate Customer Report");
		System.out.println("0. Exit");
		
		
		int input=sc.nextInt();
		switch (input) {
		case 1:
			ProductList.add_product();
			break;
		case 2:
			ProductList.display();
			break;
		case 3:
			ProductList.delete();
			break;
		case 4:
			ProductList.update();
			break;
		case 5:
			ProductList.generateProductReport();
			break;
		case 6:
			ProductList.displayCustomerDetails();
			break;
		case 7:
			ProductList.deleteCustomer();
			break;
		case 8:
			ProductList.generateCustomerReport();
			break;
		default:
				System.exit(0);
				break;
		}
	}
}
