package product;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import admin.Admin;

public class ProductList {

	public static void add_product() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
			
			
			Scanner sc= new Scanner (System.in);
			System.out.println("enter product id");
			int prod_id=sc.nextInt();
			System.out.println("enter product name (use underscore '_' instead of space ' ').");
			String prod_name=sc.next();
			System.out.println("enter product price");
			int prod_price= sc.nextInt();
			System.out.println("enter product description (use underscore '_' instead of space ' ').");
			String prod_desc=sc.next();
			
			//using statement
//			Statement stmt= con.createStatement();
//			stmt.executeUpdate("insert into product_list values ('"+prod_name+"',"+prod_price+",'"+prod_desc+"')");
			
			//using prepared statement
			PreparedStatement pstmt = con.prepareStatement("insert into product_list values(?,?,?,?)");
			
			pstmt.setInt(1, prod_id);
			pstmt.setString(2, prod_name);
			pstmt.setInt(3, prod_price);
			pstmt.setString(4, prod_desc);
			pstmt.executeUpdate();
			System.out.println("Product Added successfully");
			
			con.close();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		
		Admin.admin();
	}
//	Update data using prepared
	public static void update() throws ClassNotFoundException, IOException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
			
			
			Scanner sc= new Scanner (System.in);
			
			System.out.println("Enter Product ID To Update");
			int prod_id=sc.nextInt();
			System.out.println("Enter Product Name (use underscore '_' instead of space ' ').");
			String prod_name=sc.next();
			System.out.println("Enter the Product Price");
			int prod_price = sc.nextInt();
			System.out.println("Enter the Product Description");
			String prod_desc=sc.next();
			PreparedStatement pstmt = con.prepareStatement("update product_list set prod_name=?,prod_price=?,prod_desc=? where prod_id=?");
			//1,2 this is going to represent the sequence of the parameter in prepared statement.
			pstmt.setString(1, prod_name);
			pstmt.setInt(2, prod_price);
			pstmt.setString(3,prod_desc);
			pstmt.setInt(4, prod_id);
			pstmt.executeUpdate();
			System.out.println("Product Updated");
	
			con.close();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		Admin.admin();
		
	}
	
	public static void display() throws ClassNotFoundException, IOException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
			
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from product_list") ; //"select * from Product"
			while(rs.next()) {
				System.out.println("Product ID- "+rs.getInt(1)+
						" Product Name- '"+rs.getString(2)+"' Product Price- "+rs.getInt(3)+" Product Description- '"+rs.getString(4)+"'.");
				System.out.println();
			}
	
			con.close();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		Admin.admin();
	}

public static void delete() throws ClassNotFoundException, IOException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
			
			Scanner sc= new Scanner (System.in);
			System.out.println("enter product id");
			int prod_id=sc.nextInt();
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("delete from product_list where prod_id="+prod_id);
			System.out.println("Product Deleted");
			
	
			con.close();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		Admin.admin();
	}

	public static void generateProductReport() throws IOException, ClassNotFoundException{
		
		
		
//		 FileWriter writer = new FileWriter("C:\\Users\\YogeshK3\\Desktop\\dope\\MiniProject.txt");  
//		    BufferedWriter buffer = new BufferedWriter(writer);  
//		    
//		    buffer.write("");  
//		    buffer.close();  
//		    System.out.println("Success");  
		    
		System.out.println("this module is not complete yet.");
		System.out.println();
			
		    Admin.admin();
	}
	
	public static void displayCustomerDetails() throws ClassNotFoundException, IOException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			try {
				Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
				
				Statement stmt = con.createStatement();
				
				ResultSet rs = stmt.executeQuery("select * from customer_details") ; //"select * from Product"
				while(rs.next()) {
					System.out.println("Customer ID- "+rs.getInt(1)+
							" Customer Name- '"+rs.getString(2)+" 'Customer Email- "+rs.getString(3)+" Customer Phone- '"+rs.getString(4)+"' Custmer Address- "+rs.getString(5));
					System.out.println();
				}
		
				con.close();
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
			Admin.admin();
		
	}
	
	public static void deleteCustomer() throws ClassNotFoundException, IOException {
		
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
			
			Scanner sc= new Scanner (System.in);
			System.out.println("Enter Customer Id");
			int cust_id=sc.nextInt();
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("delete from customer_details where cust_id="+cust_id);
			System.out.println("Customer Deleted");
			
	
			con.close();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		Admin.admin();
	}
	
	public static void generateCustomerReport() throws ClassNotFoundException, IOException {
		
		System.out.println("this module is not complete yet.");
		Admin.admin();
	}
}
