USE Nov25Sql

SELECT * FROM Employees

UPDATE Employees
SET Salary = 700000
WHERE EmployeeID = 1002

UPDATE Employees
SET Salary = 730000
WHERE EmployeeID = 1003

UPDATE Employees
SET Salary = 6300000
WHERE EmployeeID = 1004

SELECT * FROM Departments
SELECT * FROM Employees

--Scalar Function

CREATE FUNCTION GetSalary
(
	@EmployeeID INT
)
RETURNS INT
AS
BEGIN
	DECLARE @salary INT
	SELECT @salary = Salary
	FROM Employees
	WHERE EmployeeID = @EmployeeID
	RETURN @salary
END

SELECT dbo.GetSalary(1001) AS Salary
SELECT dbo.GetSalary(1002) AS Salary
SELECT dbo.GetSalary(1003) AS Salary
SELECT dbo.GetSalary(1004) AS Salary
SELECT dbo.GetSalary(1005) AS Salary


CREATE FUNCTION EmployeeCount
(
	@departmentId INT
)
RETURNS INT
AS
BEGIN
	DECLARE @employeeCount INT
	SELECT @employeeCount = COUNT(EmployeeID)
	FROM Employees
	WHERE DepartmentID = @departmentId
	RETURN @employeeCount
END

SELECT DepartmentID FROM Employees

SELECT dbo.EmployeeCount(1) AS "Total Employees"



CREATE FUNCTION GetEmpName
(
	@employeeID INT
)
RETURNS VARCHAR(20)
AS
BEGIN
	DECLARE @firstName VARCHAR(20)
	SELECT @firstName = FirstName
	FROM Employees
	WHERE EmployeeID = @employeeID
	RETURN @firstName
END

SELECT dbo.GetEmpName(1001) AS "Employee Name"
SELECT dbo.GetEmpName(1002) AS "Employee Name"
SELECT dbo.GetEmpName(1003) AS "Employee Name"
SELECT dbo.GetEmpName(1004) AS "Employee Name"

ALTER FUNCTION GetEmpName
(
	@employeeID INT
)
RETURNS VARCHAR(40)
AS
BEGIN
	DECLARE @fullName VARCHAR(40)
	SELECT @fullName = CONCAT(FirstName,' ',LastName)
	FROM Employees
	WHERE EmployeeID = @employeeID
	RETURN @fullName
END


SELECT dbo.GetEmpName(1001) AS "Employee Name"
SELECT dbo.GetEmpName(1002) AS "Employee Name"
SELECT dbo.GetEmpName(1003) AS "Employee Name"
SELECT dbo.GetEmpName(1004) AS "Employee Name"

DROP FUNCTION GetEmpName

SELECT dbo.GetEmpName(1001) AS "Employee Name" --Error as GetEmpName is dropped

--Inline Table Valued Function

CREATE FUNCTION GetEmployees
(
	@departmentID INT
)
RETURNS TABLE
AS
RETURN
SELECT * FROM Employees
WHERE DepartmentID = @departmentID

SELECT * FROM dbo.GetEmployees(1)


UPDATE Employees
SET DepartmentID = 3, Experience = 2
WHERE EmployeeID = 1002

SELECT * FROM Employees

ALTER FUNCTION GetEmployees
(
	@departmentID INT,
	@experience INT
)
RETURNS TABLE
AS
RETURN
SELECT * FROM Employees
WHERE DepartmentID = @departmentID AND Experience = @experience

SELECT * FROM dbo.GetEmployees(3,2)

SELECT * FROM dbo.GetEmployees(1,5)

--Stored Procedures

EXEC SP_HELP 'Departments'
SELECT * FROM Locations
SELECT * FROM Departments

CREATE PROCEDURE GetDeptName
(
	@departmentID INT,
	@departmentName VARCHAR(20) OUT
)
AS
SELECT @departmentName = DepartmentName
FROM Departments
WHERE DepartmentID = @departmentID

SELECT * FROM Departments

DECLARE @deptName VARCHAR(20)
EXEC GetDeptName 1,@deptName OUT
SELECT @deptName DepartmentName
EXEC GetDeptName 1025,@deptName OUT
SELECT @deptName DepartmentName

ALTER PROCEDURE GetDeptName
(
	@departmentID INT,
	@departmentName VARCHAR(20) OUT,
	@locationID INT OUT
)
AS
SELECT @departmentName = DepartmentName, @locationID = LocationID
FROM Departments
WHERE DepartmentID = @departmentID

DECLARE @deptName VARCHAR(20), @locID INT
EXEC GetDeptName 3,@deptName OUT,@locID OUT
SELECT @deptName AS DepartmentName,@locID LocationID

DROP Procedure GetDeptName

DECLARE @deptName VARCHAR(20), @locID INT
EXEC GetDeptName 3,@deptName OUT,@locID OUT --Error as GetDeptName is dropped

CREATE PROCEDURE AddDepartment
(
	@departmentID INT,
	@deptartmentName VARCHAR(20),
	@locationID INT
)
AS
INSERT INTO Departments
VALUES(@departmentID,@deptartmentName,@locationID)

SELECT * FROM Departments
SELECT * FROM Locations
EXEC AddDepartment  2, 'Marketing',3
SELECT * FROM Departments

ALTER PROCEDURE AddDepartment
(
	@departmentID INT,
	@deptartmentName VARCHAR(20),
	@locationID INT
)
AS
BEGIN TRY
	INSERT INTO Departments
	VALUES(@departmentID,@deptartmentName,@locationID)
END TRY
BEGIN CATCH
	PRINT @@ERROR 
	PRINT 'Someting went wrong'	
	--@@ERROR is a global variable. 
	--If @@ERROR is 0, that means code has executed successfully.
	--If @@ERROR in a non zero value, that means something has gone wrong during the code execution.
	DECLARE @severity INT = ERROR_SEVERITY(), @state INT = ERROR_STATE()
	RAISERROR('DepartmentID already exists or LocationID does not exists. Please check',@severity,@state)
END CATCH

EXEC AddDepartment  7, 'Visa Processing',3  --Works. Successfully insers a record in Department table
SELECT * FROM Departments
EXEC AddDepartment  5, 'Payroll',2  --Fails
EXEC AddDepartment  10, 'Visa Processing',7  --Fails