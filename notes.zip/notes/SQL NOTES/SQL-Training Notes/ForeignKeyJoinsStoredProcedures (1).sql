--	Foreign Key:
--	Primary Key or Unique Key column of Parent Table which is referred in the Child table
--	Used to establish the relationship between two tables.

--Rules that are enforced when you create Foreign Key:

--1) If value is not present in the parent table, it can't exist in child table as well.
--2) If you update the value is parent table, all corrosponding rows in the child table
--   should get updated.
--3) if you delete the row from the parent table, then corrosponding row in child table
--   should be deleted/column value should be set to NULL or some default value

CREATE TABLE Theaters
(
	TheaterID INT PRIMARY KEY,
	TheaterName VARCHAR(30) NOT NULL
)

CREATE TABLE Movies
(
	MovieID INT IDENTITY(101,1) PRIMARY KEY,
	MovieName VARCHAR(30) NOT NULL,
	Genre VARCHAR(20),
	TheaterID INT --REFERENCES Theaters(TheaterID) ON UPDATE CASCADE ON DELETE SET NULL 
)

ALTER TABLE Movies
ADD CONSTRAINT fk_mov_th FOREIGN KEY(TheaterID) REFERENCES Theaters(TheaterID) ON UPDATE CASCADE ON DELETE SET NULL

INSERT INTO Theaters
VALUES(1,'Gold Adlabs'),(2,'INOX'),(3,'IMAX')

INSERT INTO Theaters
VALUES(4,'PVR')

INSERT INTO Movies
VALUES('Harry Potter','Fantasy',1),('Pushpa','Action',2),('Spiderman Nowhere','Action',3),('Sholey','Drama',1),('Iron Man',NULL,NULL)

INSERT Movies
VALUES('Sholey','Drama',1)
SELECT * FROM Theaters
SELECT * FROM Movies

SELECT * FROM Movies
WHERE MovieName = 'Sholey'

CREATE NONCLUSTERED INDEX idx_Movie
ON Movies(MovieName)

DROP INDEX Movies.idx_Movie



--Foreign Key Constraint Violation
INSERT INTO Movies
VALUES('Khichdi','Comedy',4)

--ON UPDATE CASCADE
SET IDENTITY_INSERT Theaters ON

UPDATE Theaters
SET TheaterID = 7
WHERE TheaterID = 1

SELECT * FROM Theaters
SELECT * FROM Movies

--ON DELETE SET NULL

DELETE FROM Theaters
WHERE TheaterID = 2

SELECT * FROM Theaters
SELECT * FROM Movies

--Theaters Table

--TheaterID		TheaterName

--Movies Table

--MovieID		MovieName		Genre		TheaterID

--Get the data like this
--MovieID		MovieName		Genre		TheaterName

--INNER JOIN

SELECT MovieID, MovieName, Genre, TheaterName
FROM Movies mov
INNER JOIN Theaters thr
ON mov.TheaterID = thr.TheaterID

--Diplay MovieNames and TheaterNames for the relased movies
--Display Movienames for non realesed movies 
--Movies		LFET JOIN		Theaters	--All movie names

SELECT MovieID, MovieName, Genre, TheaterName
FROM Movies mov
LEFT JOIN Theaters thr
ON mov.TheaterID = thr.TheaterID

--Diplay MovieNames and TheaterNames for the relased movies
--Display TheaterNames for non realesed movies
--Movies		RIGHT JOIN		Theaters	--All theater names

SELECT MovieID, MovieName, Genre, TheaterName
FROM Movies mov
RIGHT JOIN Theaters thr
ON mov.TheaterID = thr.TheaterID

--All Movies, All Theaters

SELECT MovieID, MovieName, Genre, TheaterName
FROM Movies mov
FULL JOIN Theaters thr
ON mov.TheaterID = thr.TheaterID

--CROSS JOIN

SELECT MovieID, MovieName, Genre, TheaterName
FROM Movies
CROSS JOIN Theaters

--STORED PROCEDURE

EXEC SP_HELP 'Departments'
CREATE PROCEDURE GetDeptDetails
(
	@departmentID INT,
	@departmentName VARCHAR(30) OUT
)
AS
SELECT @departmentName = DepartmentName
FROM Departments
WHERE DepartmentID = @departmentID

SELECT * FROM Departments

DECLARE @deptName VARCHAR(30)
EXEC GetDeptDetails 1025,@deptName OUT
SELECT @deptName AS [Department Name]