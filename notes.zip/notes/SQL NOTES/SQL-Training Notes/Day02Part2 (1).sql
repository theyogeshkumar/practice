--JOINS: Useful when you need to retrieve data from mor than one table

SELECT * FROM Departments
SELECT * FROM Employees

--Types of Joins

--INNER JOIN: Retrieves matching data fom both the tables

SELECT EmployeeID,FirstName,LastName,DepartmentName
FROM Employees emp
INNER JOIN Departments dept
ON emp.DepartmentID = dept.DepartmentID

--OUTER JOIN: Retrieves all records from one table and matching records from another table

--LEFT OUTER JOIN: Retrieve all records from the table on the left hand side of Join clause
--and matching records from able on the right hand side of Join clause

SELECT EmployeeID,FirstName,LastName,DepartmentName
FROM Employees emp
LEFT OUTER JOIN Departments dept
ON emp.DepartmentID = dept.DepartmentID
--WHERE emp.DepartmentID IS NULL

--RIGHT OUTER JOIN: Retrieve all records from the table on the right hand side of Join clause
--and matching records from able on the lfet hand side of Join clause

SELECT EmployeeID,FirstName,LastName,DepartmentName
FROM Employees emp
RIGHT OUTER JOIN Departments dept
ON emp.DepartmentID = dept.DepartmentID

--FULL OUTER JOIN
SELECT EmployeeID,FirstName,LastName,DepartmentName
FROM Employees emp
FULL OUTER JOIN Departments dept
ON emp.DepartmentID = dept.DepartmentID

ALTER TABLE Employees
ADD ManagerID INT

--Add the ManagerID to existing Employee records.
SELECT * FROM Employees

--SELF JOIN : Retrieve Manager Name of Employee
SELECT emp.EmployeeID, emp.FirstName, emp.LastName,emp.ManagerID,mgr.FirstName AS ManagerName,mgr.LastName AS ManagerSurname
FROM Employees emp
INNER JOIN Employees mgr
ON emp.ManagerID = mgr.EmployeeID

CREATE TABLE Locations
(
	LocationID INT NOT NULL PRIMARY KEY,
	LocationName VARCHAR(30) NOT NULL
)

INSERT INTO Locations
VALUES(1,'Mumbai'),(2,'Pune'),(3,'Bengaluru')

ALTER TABLE Departments
ADD LocationID INT REFERENCES Locations(LocationID)
ON UPDATE CASCADE ON DELETE SET NULL

SELECT * FROM Departments
SELECT * FROM Locations

UPDATE Departments
SET LocationID = 1
WHERE DepartmentID = 1

UPDATE Departments
SET LocationID = 2
WHERE DepartmentID = 4

--JOINING THREE TABLES
--Display EmployeeID, FirstName, LastName, DepartmentName, LocationName

SELECT emp.EmployeeID, emp.FirstName, emp.LastName, dept.DepartmentName,loc.LocationName
FROM Employees emp
INNER JOIN Departments dept
ON emp.DepartmentID = dept.DepartmentID
RIGHT OUTER JOIN Locations loc
ON loc.LocationID = dept.LocationID



