--SEQUENCE
USE Nov25Sql

CREATE SEQUENCE IdSequnce
AS INT
START WITH 1024
INCREMENT BY 1
MINVALUE 1000
MAXVALUE 32768
CYCLE
CACHE 3

SELECT NEXT VALUE FOR IdSequnce

EXEC SP_HELP 'Departments'

SELECT * FROM Departments

INSERT INTO Departments
VALUES(NEXT VALUE FOR IdSequnce,'HR',1)

INSERT INTO Departments
VALUES(NEXT VALUE FOR IdSequnce,'Sales',2)

ALTER SEQUENCE IdSequnce
INCREMENT BY 1
MINVALUE 1010
MAXVALUE 32768
CYCLE
CACHE 3

SELECT NEXT VALUE FOR IdSequnce

DROP SEQUENCE IdSequnce

SELECT * FROM Employees

EXEC SP_HELP 'Employees'

--Views

CREATE VIEW EmplView
AS
SELECT EmployeeID,FirstName,PermanentAddress
FROM Employees

SELECT * FROM EmplView

--Error as LastName is a mandatory column
INSERT INTO EmplView
VALUES('Foo','Bar')

ALTER VIEW EmplView
AS
SELECT EmployeeID,FirstName,LastName,PermanentAddress
FROM Employees

SELECT * FROM EmplView
SELECT * FROM Employees

INSERT INTO EmplView
VALUES('Mitali','Raj','Kochi')

UPDATE EmplView
SET PermanentAddress = 'Madrid,Spain'
WHERE EmployeeID = 1011

SELECT * FROM EmplView
SELECT * FROM Employees

UPDATE Employees
SET FirstName = 'V'
WHERE EmployeeID = 1011

DROP TABLE Employees

EXEC SP_HELP 'Employees'
EXEC SP_HELP 'EmpProj'

ALTER TABLE Employees
DROP CONSTRAINT fk_emp_dept

ALTER TABLE EmpProj
DROP CONSTRAINT FK__EmpProj__Employe__6A30C649

DROP TABLE Employees

SELECT * FROM EmplView

CREATE TABLE Employees
(
	EmployeeID INT IDENTITY(1001,1) PRIMARY KEY,
	FirstName VARCHAR(20) NOT NULL,
	LastName VARCHAR(20) NOT NULL,
	PermanentAddress VARCHAR(250) UNIQUE,
	Salary INT CHECK(Salary>60000),
	Experience INT DEFAULT 0,
	DepartmentID INT REFERENCES Departments(DepartmentID) ON UPDATE CASCADE ON DELETE SET NULL
)

INSERT INTO Employees
VALUES('Sachin','Tendulkar','Mumbai',6500000,5,1)

INSERT INTO Employees
VALUES('Virat','Kohli','New Delhi',6500000,5,1)

INSERT INTO Employees
VALUES('Saina','Nehwal',NULL,6500000,5,1)

INSERT INTO Employees(FirstName,LastName,PermanentAddress,Salary,DepartmentID)
VALUES('Pusarla','Sindhu','Hyderabad',6500000,NULL)

SELECT * FROM Employees

SELECT * FROM EmplView

ALTER VIEW EmplView
WITH SCHEMABINDING		--Prevents dropping the table on which this view is based. 
AS
SELECT EmployeeID,FirstName,LastName,PermanentAddress
FROM dbo.Employees

--WITH SCHEMABINDING can be used with CREATE VIEW as well

--Two Part		: schemaname.tablename  dbo.Employees
--Three Part	    : database name.schemaname.tablename     Nov25Sql.dbo.Employees 
--Four Part       : database server name.database name.schemaname.tablename
--                  IMCCBCP52-MSL2\SQLEXPRESS2019.Nov25Sql.dbo.Employees 

DROP TABLE Employees  --Error as EmplView is now schema bound

EXEC SP_HELPTEXT 'EmplView'

ALTER VIEW EmplView
WITH SCHEMABINDING, ENCRYPTION		
AS
SELECT EmployeeID,FirstName,LastName,PermanentAddress
FROM dbo.Employees

--SCHEMABINDING : Prevents dropping the table on which this view is based. 
--ENCRYPTION    : Prevents displaying the text which is used to create the view.

EXEC SP_HELPTEXT 'EmplView'

DROP VIEW EmplView

SELECT * FROM EmplView

CREATE VIEW EmplView
AS
SELECT EmployeeID,FirstName,LastName,PermanentAddress
FROM Employees

