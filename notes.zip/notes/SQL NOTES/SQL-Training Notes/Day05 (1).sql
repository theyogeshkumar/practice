USE Nov25Sql

--INDEXES
--Reference URL for Theory: https://www.sqlservertutorial.net/sql-server-indexes/

CREATE TABLE DemoIndex
(
	A INT NOT NULL,
	B VARCHAR(30),
	C VARCHAR(30)
)

INSERT INTO DemoIndex
VALUES(10,'Apple','Shimla'),(3,'Apple','Shrinagar'),(8,'Apple','New Zealand'),(1,'Pear','Shedong')

SELECT * FROM DemoIndex

--CLUSTERED INDEX

CREATE CLUSTERED INDEX idx_A
ON DemoIndex(A)

SELECT * FROM DemoIndex

EXEC SP_HELP 'DemoIndex'

INSERT INTO DemoIndex
VALUES(7,'Dragon Fruit','Singapore')

INSERT INTO DemoIndex
VALUES(8,'Papaya','India')

INSERT INTO DemoIndex
VALUES(8,'Banana','India')

DROP INDEX DemoIndex.idx_A

DELETE FROM DemoIndex
WHERE B = 'Banana'

DELETE FROM DemoIndex
WHERE B = 'Papaya'

--UNIQUE CLUSTERED INDEX

CREATE UNIQUE CLUSTERED INDEX idx_A
ON DemoIndex(A)

INSERT INTO DemoIndex
VALUES(7,'Dragon Fruit','Singapore')

EXEC SP_HELP 'DemoIndex'

DROP INDEX DemoIndex.idx_A

ALTER TABLE DemoIndex
ADD CONSTRAINT pk_DemoIndex PRIMARY KEY(A)

EXEC SP_HELP 'DemoIndex'

--NONCLUATERED INDEX

CREATE NONCLUSTERED INDEX idx_B
ON DemoIndex(B)

SELECT * FROM DemoIndex

SELECT * FROM DemoIndex
WHERE B='Apple'

DROP INDEX DemoIndex.idx_B

--TRIGGERS
-- Reference URL: https://www.c-sharpcorner.com/UploadFile/a53f1a/triggers-in-sql-server/

CREATE TABLE A(Col1 INT)
CREATE TABLE B(Col2 INT)
CREATE TABLE C(Col3 INT)

CREATE TRIGGER AddTrigger
ON A
FOR INSERT
AS
INSERT INTO B
SELECT * FROM inserted

INSERT INTO A
VALUES(100)

SELECT * FROM A
SELECT * FROM B
SELECT * FROM C

INSERT INTO B
VALUES(500)

DROP TRIGGER AddTrigger

TRUNCATE TABLE C

CREATE TRIGGER RemoveTrig
ON A
FOR DELETE
AS
INSERT INTO C
SELECT * FROM deleted


DELETE FROM A
WHERE Col1=100

INSERT INTO C
VALUES(1000)

SELECT * FROM Employees

DELETE FROM Employees
WHERE EmployeeID = 1002

SELECT * FROM Employees

--INSTEAD OF TRIGGER

CREATE TRIGGER NoEmpDelete
ON Employees
INSTEAD OF DELETE
AS
BEGIN
	PRINT 'Employee record cannot be deleted. It can be marked as inactive.'
	ROLLBACK
END

ALTER TRIGGER NoEmpDelete
ON Employees
INSTEAD OF DELETE
AS
BEGIN
	PRINT 'Employee record cannot be deleted. It can be marked as inactive.'
END

DELETE FROM Employees
WHERE EmployeeID = 1003

EXEC SP_HELP 'A'


--Common Table Expressions (CTEs):

WITH emp_detail(FirstName,LastName,DeptName)
AS
(
	SELECT FirstName,LastName,DepartmentName
	FROM Employees emp
	INNER JOIN Departments dept
	ON emp.DepartmentID = dept.DepartmentID
)
SELECT * FROM emp_detail

CREATE TABLE Staff
(
  EmployeeID int NOT NULL PRIMARY KEY,
  FirstName varchar(50) NOT NULL,
  LastName varchar(50) NOT NULL,
  ManagerID int NULL
)

INSERT INTO Staff VALUES (1, 'Ken', 'Thompson', NULL)
INSERT INTO Staff VALUES (2, 'Terri', 'Ryan', 1)
INSERT INTO Staff VALUES (3, 'Robert', 'Durello', 1)
INSERT INTO Staff VALUES (4, 'Rob', 'Bailey', 2)
INSERT INTO Staff VALUES (5, 'Kent', 'Erickson', 2)
INSERT INTO Staff VALUES (6, 'Bill', 'Goldberg', 3)
INSERT INTO Staff VALUES (7, 'Ryan', 'Miller', 3)
INSERT INTO Staff VALUES (8, 'Dane', 'Mark', 5)
INSERT INTO Staff VALUES (9, 'Charles', 'Matthew', 6)
INSERT INTO Staff VALUES (10, 'Michael', 'Jhonson', 6)

SELECT * FROM Staff

WITH
  cteReports (EmpID, FirstName, LastName, MgrID, EmpLevel)
  AS
  (
    SELECT EmployeeID, FirstName, LastName, ManagerID, 1
    FROM Staff
    WHERE ManagerID IS NULL
    UNION ALL
    SELECT e.EmployeeID, e.FirstName, e.LastName, e.ManagerID, 
      r.EmpLevel + 1
    FROM Staff e
      INNER JOIN cteReports r
        ON e.ManagerID = r.EmpID
  )
SELECT
  FirstName + ' ' + LastName AS FullName, 
  EmpLevel,
  (SELECT FirstName + ' ' + LastName FROM Staff 
    WHERE EmployeeID = cteReports.MgrID) AS Manager
FROM cteReports 
ORDER BY EmpLevel, MgrID 

WITH
  cteReports (EmpID, FirstName, LastName, MgrID, EmpLevel)
  AS
  (
    SELECT EmployeeID, FirstName, LastName, ManagerID, 1
    FROM Staff
    WHERE ManagerID IS NULL
    UNION ALL
    SELECT e.EmployeeID, e.FirstName, e.LastName, e.ManagerID, 
      r.EmpLevel + 1
    FROM Staff e
      INNER JOIN cteReports r
        ON e.ManagerID = r.EmpID
  )  
  SELECT * FROM cteReports


--Ranking Functions:
--Reference URL: https://www.c-sharpcorner.com/article/the-complete-reference-ranking-functions-in-ms-sql-rownumber-rank-dens/

CREATE TABLE Member  
(  
  Id INT PRIMARY KEY,  
  Name VARCHAR(25),  
  Point INT  
)  

INSERT INTO Member VALUES (1,'Sachin', 978)  
INSERT INTO Member VALUES (2,'Rahul', 773)  
INSERT INTO Member VALUES (3,'Kamplesh', 1141)  
INSERT INTO Member VALUES (4,'Chirag', 773)  
INSERT INTO Member VALUES (5,'Pratik', 1242)  
INSERT INTO Member VALUES (6,'Rajesh', 1141)  
INSERT INTO Member VALUES (7,'Anil', 886)  

SELECT ROW_NUMBER() OVER( ORDER BY Name) AS SrNo, Name FROM Member  
SELECT RANK() OVER( ORDER BY Point desc) AS [Rank], Name, Point FROM Member 
SELECT DENSE_RANK() OVER( ORDER BY Point desc) AS [Rank], Name, Point FROM Member 
SELECT ROW_NUMBER() OVER( PARTITION BY Point ORDER BY Point) AS [Rank]
, Name, Point FROM Member
  ORDER BY Point DESC
SELECT NTILE(3) OVER( ORDER BY Point desc) AS [Rank], Name, Point FROM Member  

--Analytical Functions
--Reference URL: https://www.sqlshack.com/an-overview-of-analytic-functions-in-sql-server/
--The OVER clause is used to determine which rows from the query are applied to the 
--function, what order they are evaluated in by that function, and when the function�s 
--calculations should restart. 
--You can use the OVER clause with functions to compute aggregated values such as 
--moving averages, cumulative aggregates, running totals, or a top N per group results.

--SCRIPT FOR ANALYTICAL FUNCTIONS

CREATE TABLE Laptops(
	LaptopID		INT IDENTITY(1,1) PRIMARY KEY,
	LaptopName		VARCHAR(100),
	LaptopBrand		VARCHAR(100),
	ReleasedYear	INT,
	DeviceType		VARCHAR(100),
	Price			DECIMAL(9,2)
)
GO

INSERT INTO Laptops (LaptopName,LaptopBrand,ReleasedYear,DeviceType,Price) VALUES
('Microsoft Surface Laptop 4 15-inch','Microsoft',2017,'Office',130),
('Microsoft Surface Pro 7+','Microsoft',2019,'Office',140),
('Apple MacBook Air (M1, 2020)','Apple',2020,'Business',90),
('Apple MacBook Air MREA2HN/A','Apple',2021,'Business',100),
('Dell XPS 13 9310','Dell',2021,'Office',150),
('Dell XPS 15 9500','Dell',2021,'Gaming',200),
('Dell G5 15 SE 5505','Dell',2020,'Business',75),
('HP Chromebook 11a','HP',2020,'Business',20)
GO

INSERT INTO Laptops
VALUES('Lenovo Thinkpad','IBM',2020,'Business',300)

UPDATE Laptops
SET Price = 120
WHERE LaptopID = 9

INSERT INTO Laptops
VALUES('Dell Inspiron 3511','Dell',2020,'Office',150)

SELECT * FROM Laptops

SELECT 
	LaptopName, 
	LaptopBrand, 
	ReleasedYear, 
	DeviceType, 
	Price,
	CUME_DIST() OVER(ORDER BY Price) AS PriceDistribution
FROM [dbo].[Laptops]

SELECT 
	LaptopName, 
	LaptopBrand, 
	ReleasedYear, 
	DeviceType, 
	Price,
	CUME_DIST() OVER(PARTITION BY DeviceType ORDER BY Price) AS PriceDistribution
FROM [dbo].[Laptops]

SELECT LaptopName, LaptopBrand, ReleasedYear, DeviceType, Price,
FIRST_VALUE(LaptopName) OVER(ORDER BY Price) AS FirstValue
FROM [dbo].[Laptops]

SELECT LaptopName, LaptopBrand, ReleasedYear, DeviceType, Price,
FIRST_VALUE(LaptopName) OVER(PARTITION BY LaptopBrand ORDER BY Price) AS FirstValue
FROM [dbo].[Laptops]

SELECT LaptopName, LaptopBrand, ReleasedYear, DeviceType, Price,
LAST_VALUE(LaptopName) OVER(ORDER BY Price) AS LastValue
FROM [dbo].[Laptops]

SELECT LaptopName, LaptopBrand, ReleasedYear, DeviceType, Price,
LAST_VALUE(LaptopName) OVER(ORDER BY Price
ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS LastValue
FROM [dbo].[Laptops]

SELECT LaptopName, LaptopBrand, ReleasedYear, DeviceType, Price,
LEAD(LaptopName,1) OVER(ORDER BY Price) AS FirstOffset,
LEAD(LaptopName,2) OVER(ORDER BY Price) AS SecondOffset
FROM [dbo].[Laptops]

SELECT LaptopName, LaptopBrand, ReleasedYear, DeviceType, Price,
LAG(LaptopName,1) OVER(ORDER BY Price) AS FirstOffset,
LAG(LaptopName,2) OVER(ORDER BY Price) AS SecondOffset
FROM [dbo].[Laptops]
