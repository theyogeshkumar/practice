CREATE TABLE Categories
(
	CategoryID int PRIMARY KEY,
	CategoryName varchar(30) NOT NULL
)

CREATE TABLE Suppliers
(
	SupplierID int PRIMARY KEY,
	SupplierName varchar(30) NOT NULL
)

CREATE TABLE Products
(
	ProductID INT PRIMARY KEY,
	ProductName VARCHAR(30) NOT NULL,
	CategoryID INT REFERENCES Categories(CategoryID) ON UPDATE CASCADE ON DELETE SET NULL,
	SupplierID INT REFERENCES Suppliers(SupplierID) ON UPDATE CASCADE ON DELETE SET NULL,
	Price DECIMAL(6,2)
)

CREATE TABLE Orders
(
	OrderID INT IDENTITY PRIMARY KEY,
	ProductID INT REFERENCES Products(ProductID) ON UPDATE CASCADE,
	Quantity INT NOT NULL
)

--Add some records to Categories, Suppliers, Products and Orders tables
SELECT * FROM Categories
SELECT * FROM Suppliers
SELECT * FROM Products
SELECT * FROM Orders

--Subsquery to retrieve details of the products supplied by supplier named DMart
SELECT ProductID,ProductName
FROM Products
WHERE SupplierID = (
	SELECT SupplierID FROM Suppliers
	WHERE SupplierName = 'DMart'
)

--Subquery to retrieve details of suppliers who are supplying product named Shirts
SELECT SupplierID,SupplierName
FROM Suppliers
WHERE SupplierID IN (SELECT SupplierID FROM PRODUCTS
WHERE ProductName = 'Shirts')

--Subquery to retrieve details of suppliers who are supplying product named Pulses or Chips
SELECT SupplierID,SupplierName
FROM Suppliers
WHERE SupplierID = ANY(
	SELECT DISTINCT SupplierID FROM Products
	WHERE ProductName = 'Pulses' OR ProductName = 'Chips'
)

SELECT * FROM Orders

--Subquery to retrieve details of products with quantity between 100 and 150
SELECT ProductName 
FROM Products
WHERE ProductID = ALL (SELECT ProductID
                       FROM Orders
                       WHERE Quantity>=100 AND Quantity <= 150);

SELECT ALL ProductName
FROM Products

--Subquery for checking the existence
SELECT DISTINCT ProductName
FROM Products
WHERE EXISTS (
	SELECT SupplierID FROM Suppliers
	WHERE SupplierName = 'Walmart'
)

SELECT DISTINCT ProductName
FROM Products
WHERE NOT EXISTS (
	SELECT SupplierID FROM Suppliers
	WHERE SupplierName = 'Walmart'
)

--Built-In Functions

--Numeric Functions:

SELECT ABS(-178) AS "Absolute Value"
SELECT ROUND(123.985474,2) AS "Rounded"
SELECT CEILING(10.44) AS "Ceiling"
SELECT FLOOR(10.44) AS "Floor"
SELECT SQRT(81) AS "SquareRoot"
SELECT SQUARE(4) AS "Square"
SELECT POWER(7,3) AS "Raise To"
SELECT EXP(1) AS "Base e Equivalent"
SELECT PI() As "Constant PI"

--STRING Functions
SELECT ASCII('C')as "ASCII Value"
SELECT CHAR(99) AS "ASCII Character"
SELECT CHARINDEX('t', 'test') AS MatchPosition;
SELECT CHARINDEX('OM', 'Customer') AS MatchPosition;
SELECT CHARINDEX('mer', 'Customer', 3) AS MatchPosition;
SELECT CONCAT(FirstName,' ',LastName) AS FullName FROM Employees
SELECT LEN(FirstName) AS "Length" FROM Employees
SELECT LTRIM('      Sachin              ') AS "Leading Spaces"
SELECT RTRIM('      Sachin              ') AS "Trailing"
SELECT TRIM('      Sachin              ') AS "NoGaps"
SELECT STR(100) AS "NumeberString"
SELECT SUBSTRING(FirstName,1,3) AS "3 Chars" FROM Employees
SELECT LEFT(FirstName,4) AS "CharsFromLeft" FROM Employees
SELECT RIGHT(LastName,4) AS "CharsFromRight" FROM Employees
SELECT UPPER(FirstName) AS "UpperCase" FROM Employees
SELECT LOWER(FirstName) AS "LowerCase" FROM Employees
SELECT REPLACE('DonaldMickey','Mickey','Duck')  As "Replace"

--DATE FUNCTIONS
SELECT GETDATE() AS "Current Date and Time"
SELECT DAY(GETDATE()) AS "Date"
SELECT MONTH(GETDATE()) AS "Month"
SELECT YEAR('11/22/2021') AS "Year"
SELECT DATEADD(dd,2,GETDATE()) AS "Delivery Date"
SELECT DATEDIFF(mm,'12/10/2019',GETDATE()) As "Months Between"
SELECT DATEFROMPARTS(2018, 10, 31) AS DateFromParts
SELECT DATEPART(wk,GETDATE()) AS "Ongoing Week"
SELECT DATEPART(dw,GETDATE()) AS "WeekDay No"
SELECT DATENAME(dw, '2017/08/25') AS "WeekDay";
SELECT DATENAME(mm,'2017/08/25') AS "Month";
SELECT GETDATE() as "GMT Date"
SELECT GETUTCDATE() AS "UTC Date"
SELECT SYSDATETIME()
SELECT SYSDATETIMEOFFSET()
--datepart			Abbreviations
--year				yy, yyy
--quarter			qq, q
--month				mm, m
--dayofyear			dy, y
--day				dd, d
--week				wk, ww
--weekday			dw
--hour				hh
--minute			mi, n
--second			ss, s
--millisecond		ms
--microsecond		mcs
--nanosecond		ns
--tzoffset			tz
--iso_week			isowk, isow


--ADVANCED FUNCTIONS
SELECT GETDATE()AS "CurrentDate"
SELECT CAST(GETDATE() AS VARCHAR(12)) AS "Cast"
SELECT CONVERT(VARCHAR(12),GETDATE(),113) AS "Convert"  --Last parameter can be between 101 and 113

--AGGREGATE FUNCTIONS
SELECT SUM(SALARY) AS "Total Salary Paid" FROM Employees
SELECT MIN(SALARY) AS "Minimum Salary Paid" FROM Employees
SELECT MAX(SALARY) AS "Maximum Salary Paid" FROM Employees
SELECT AVG(SALARY) AS "Average Salary Paid" FROM Employees
SELECT COUNT(DepartmentID) AS "No of Agents" FROM Employees
SELECT COUNT(*) FROM Employees


--GROUP BY HAVING

SELECT  DepartmentID,Count(*) AS "No of Employees"
FROM Employees
GROUP BY DepartmentID

SELECT DepartmentID, SUM(Salary) as "Total Salary"
FROM Employees
GROUP BY DepartmentID

SELECT * FROM Products

SELECT ProductName,SUM(Price) AS "Total Price"
FROM Products
GROUP BY ProductName

SELECT ProductName,SUM(Price) AS "Total Price"
FROM Products
GROUP BY ProductName
HAVING SUM(Price)>300
ORDER BY ProductName DESC

SELECT * FROM Products

SELECT * FROM Orders

SELECT ProductID,SUM(Quantity) AS "Total Quantity"
FROM Orders
GROUP BY ProductID,Quantity

--SET Operators

--Used to combine same type of data from two or more tables

--Restrictions
--Number of columns, datatypes of columns and order of columns in all the 
--select statements should be same

CREATE TABLE Authors(AuthorName VARCHAR(30) NOT NULL)
CREATE TABLE Speakers(SpeakerName VARCHAR(30) NOT NULL)

INSERT INTO Authors
VALUES('Sachin Tendulkar'),('A P J Abdul Kalam'),('Sydney Sheldon'),('J K Rowling')

INSERT INTO Speakers
VALUES('Barak Obama'),('A P J Abdul Kalam'),('Bill Clinton'),('Om Birla')

SELECT * FROM Authors
SELECT * FROM Speakers

--Union :  Combines the values from two or more tables

SELECT AuthorName AS "Authors and Speakers" FROM Authors
UNION
SELECT SpeakerName FROM Speakers 
ORDER BY AuthorName

 --Union All : Combines the values from two or more tables with duplicates

SELECT AuthorName AS "Authors and Speakers" FROM Authors
UNION ALL
SELECT SpeakerName FROM Speakers

--INTERSECT : Common records from two or more tables

--Authors who are Speakers

SELECT AuthorName AS "Authors who are Speakers" FROM Authors
INTERSECT
SELECT SpeakerName FROM Speakers

--EXCEPT : Uncommon records from two or more tables

--Authors who are not Speakers

SELECT AuthorName AS "Authors who are not Speakers" FROM Authors
EXCEPT
SELECT SpeakerName FROM Speakers


--Distinct, Top, Between, Like
SELECT * FROM sys.objects where type='u'

SELECT * FROM Employees

SELECT DISTINCT Salary
FROM Employees

UPDATE Employees
SET Salary = 4500000
WHERE PermanentAddress IS NULL

UPDATE Employees
SET Salary = 4900000
WHERE EmployeeID = 1003

SELECT * FROM Employees
WHERE Salary BETWEEN 4500000 AND 5000000

SELECT TOP 3 Salary FROM Employees

SELECT TOP 3 * FROM Employees

SELECT * FROM Employees
WHERE FirstName LIKE 's%'

SELECT * FROM Employees
WHERE LastName LIKE '%i'

SELECT * FROM Employees
WHERE FirstName LIKE '%a%'


