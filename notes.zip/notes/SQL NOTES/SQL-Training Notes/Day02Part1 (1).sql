--Constraints


USE Nov25Sql

DROP TABLE Departments

DROP TABLE test.Departments

CREATE TABLE Departments
(
	DepartmentID INT IDENTITY PRIMARY KEY,
	DepartmentName VARCHAR(20) NOT NULL
)

CREATE TABLE Employees
(
	EmployeeID INT IDENTITY(1001,1) PRIMARY KEY,
	FirstName VARCHAR(20) NOT NULL,
	LastName VARCHAR(20) NOT NULL,
	PermanentAddress VARCHAR(250) UNIQUE,
	Salary INT CHECK(Salary>60000),
	Experience INT DEFAULT 0,
	DepartmentID INT REFERENCES Departments(DepartmentID) ON UPDATE CASCADE ON DELETE SET NULL
)

INSERT INTO Departments
VALUES('IT'),('HR'),('Admin'),('Finance')

SELECT * FROM Departments

INSERT INTO Employees
VALUES('Sachin','Tendulkar','Mumbai',6500000,5,1)

SELECT * FROM Employees

--Error as PermanentAddress is Unique
INSERT INTO Employees
VALUES('Virat','Kohli','Mumbai',6500000,5,1)

INSERT INTO Employees
VALUES('Virat','Kohli',NULL,6500000,5,1)

--Error as Column with Unique constraint canhave only one NULL value
INSERT INTO Employees
VALUES('Saina','Nehwal',NULL,6500000,5,1)

--Experience column for below record will have value 0 due to Default constraint
INSERT INTO Employees(FirstName,LastName,PermanentAddress,Salary)
VALUES('Saina','Nehwal','NE',6500000)

INSERT INTO Employees(FirstName,LastName,PermanentAddress,Salary,DepartmentID)
VALUES('Virat','Kohli','new Delhi',6500000,NULL)

SELECT * FROM Employees
SELECT * FROM Departments

--Foreign Key

--Error as Foreign Key column cannot contain a value which is not present in Parent table.
INSERT INTO Employees(FirstName,LastName,PermanentAddress,Salary,DepartmentID)
VALUES('Vishwanathan','Anand','Spain',5000000,5)

--The staement below works as there exists Department with DepartmentID 2
INSERT INTO Employees(FirstName,LastName,PermanentAddress,Salary,DepartmentID)
VALUES('Vishwanathan','Anand','Spain',5000000,2)

SELECT * FROM Departments
SELECT * FROM Employees

EXEC SP_HELP 'Employees'

--Dropping Foreign key Constraint to faciliate deletion of Departments table
ALTER TABLE Employees
DROP CONSTRAINT FK__Employees__Depar__628FA481

DROP TABLE Departments

CREATE TABLE Departments
(
	DepartmentID INT PRIMARY KEY,
	DepartmentName VARCHAR(20) NOT NULL
)

INSERT INTO Departments
VALUES(1,'IT'),(2,'HR'),(3,'Admin')

--Primary Key Violation
INSERT INTO Departments
VALUES(1,'Finance')

INSERT INTO Departments
VALUES(NULL,'Finance')

--Works
INSERT INTO Departments
VALUES(4,'Finance')

SELECT * FROM Departments

ALTER TABLE Employees
ADD CONSTRAINT fk_emp_dept FOREIGN KEY(DepartmentID) REFERENCES Departments(DepartmentID)
ON UPDATE CASCADE ON DELETE SET NULL

SELECT * FROM Departments
SELECT * FROM Employees

--ON UPDATE CASCADE

UPDATE Departments
SET DepartmentID = 7
WHERE DepartmentID = 1

SELECT * FROM Departments
SELECT * FROM Employees

--ON DELETE SET NULL
DELETE Departments
WHERE DepartmentID = 2

SELECT * FROM Departments
SELECT * FROM Employees

--Composite Primary Key

CREATE TABLE Projects
(	
	ProjectID INT PRIMARY KEY,
	ProjectName VARCHAR(50) NOT NULL
)

INSERT INTO Projects
VALUES(101,'LMS'),(102,'HRMS')

SELECT * FROM Projects

CREATE TABLE EmpProj
(
	EmployeeID INT REFERENCES Employees(EmployeeID),
    ProjectID INT REFERENCES Projects(ProjectID),
	CONSTRAINT pk_emp_proj PRIMARY KEY(EmployeeID,ProjectID)
)

SELECT EmployeeID FROM Employees
SELECT ProjectID FROM Projects

INSERT INTO EmpProj
VALUES(1005,101)

INSERT INTO EmpProj
VALUES(1005,102)

INSERT INTO EmpProj
VALUES(1003,101)

INSERT INTO EmpProj
VALUES(1003,102)

--Error as Composite Primary Key is Violated
INSERT INTO EmpProj
VALUES(1005,102)

--Error as ProjectID 103 does not exists
INSERT INTO EmpProj
VALUES(1005,103)

SELECT * FROM EmpProj