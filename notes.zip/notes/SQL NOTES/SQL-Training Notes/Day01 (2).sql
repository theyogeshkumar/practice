CREATE DATABASE Nov25Sql  --create a database

USE Nov25Sql  --make database active database

CREATE TABLE Students
(
	RollNo INT IDENTITY(101,1) PRIMARY KEY,
	FirstName VARCHAR(20) NOT NULL,
	LastName VARCHAR(20) NOT NULL,
	DOB SMALLDATETIME
)

EXEC sp_help 'Students'  -- View the table structure

ALTER TABLE Students
ADD ContactNo BIGINT

ALTER TABLE Students
ADD Address1 VARCHAR(250), Address2 VARCHAR(250)

EXEC sp_help 'Students'

ALTER TABLE Students
ALTER COLUMN FirstName NVARCHAR(15)

ALTER TABLE Students
ALTER COLUMN LastName NVARCHAR(15)

ALTER TABLE Students
ADD Address VARCHAR(250)

ALTER TABLE Students
DROP COLUMN Address1, Address2

EXEC SP_HELP 'Students'

DROP TABLE Students

EXEC SP_HELP 'Students' ----Error as Students table is now removed from database.


CREATE TABLE Departments
(
	DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
	DepartmentName VARCHAR(30) NOT NULL,
	DateOfCreation SMALLDATETIME,
	Capacity INT
)

EXEC SP_HELP 'Departments'

INSERT INTO Departments
VALUES('IT','12/8/2021',200)

INSERT INTO Departments
VALUES('HR','12/5/2021',50),('Admin','8/6/2021',75),('Finance','09/09/2021',100)

INSERT INTO Departments(DepartmentName,DateOfCreation)
VALUES('Sales','10/1/2021')  

--T-SQL : Transact SQL : Programming Language of SQL Server
INSERT Departments
VALUES('Marketing','1/7/2021',10)

--Querying the records

--Querying all rows and all columns from the table

SELECT * FROM Departments

--Querying selected set of rows and all columns

SELECT * FROM Departments
WHERE Capacity < 100

--Querying selected set rows and selected set of columns

SELECT DepartmentID,DepartmentName,Capacity
FROM Departments
WHERE Capacity < 100

--Sorting the Records

SELECT DepartmentID,DepartmentName,Capacity
FROM Departments
ORDER BY DepartmentName ASC --Ascending Order Sort. Specifying ASC optional

SELECT DepartmentID,DepartmentName,Capacity
FROM Departments
ORDER BY Capacity DESC --Descending Order Sorting

--Editing the Existing Records

UPDATE Departments
SET DepartmentName = 'Accounts and Finance'
WHERE DepartmentID = 4

SELECT DepartmentName
FROM Departments
WHERE DepartmentID = 4

UPDATE Departments 
SET DepartmentName = 'Digital Marketing', Capacity = 15
WHERE DepartmentID = 6

SELECT DepartmentName, Capacity
FROM Departments
WHERE DepartmentID = 6 

SELECT DepartmentName
FROM Departments

UPDATE Departments
SET DepartmentName = 'InfoSec'

SELECT DepartmentName
FROM Departments

SELECT * FROM Departments

--Removing the records

DELETE FROM Departments
WHERE DepartmentID = 6

SELECT * FROM Departments

DELETE FROM Departments   -- Deletes all the records in the Departments table

SELECT * FROM Departments -- Displays Empty Table

INSERT INTO Departments
VALUES('HR','12/5/2021',50),('Admin','8/6/2021',75),('Finance','09/09/2021',100)

SELECT * FROM Departments   -- Displays DepartmentID from 7 as DELETE doesn't reset the IDENTITY counter

TRUNCATE TABLE Departments

SELECT * FROM Departments  -- Displays Empty Table

INSERT INTO Departments
VALUES('HR','12/5/2021',50),('Admin','8/6/2021',75),('Finance','09/09/2021',100)

SELECT * FROM Departments  -- Displays DepartmentID from 1 as TRUNCATE resets the IDENTITY counter