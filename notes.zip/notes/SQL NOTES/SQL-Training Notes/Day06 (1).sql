	--Transactions:

	--Transaction is a logical unit of work.
	--Transactions make sure that there are no partial updates to the database.

	--E.g. - Recharge a Mobile:
	--	1) Your mobile no balance goes up
	--	2) Your bank account balance comes down
	--Either both these things will happen or nothing will happen.
	

	--ACID: Atomicity, Consistency, Isolation and Durability

	--Atomicity    : Ensures that there are not partial updates
	--Consistency  : Ensures that constraints are not bypassed merely because some statement(s)
	--			   executed as a part of the transaction.
	--Isolation    : Each transaction executes in isolation and its effects are not visible
 --                  to the outside world unless transaction finishes its execution.
	--Durability   : Changes made by transactions are persisted in the database unless
 --                  there is some other transaction making the change.

	--Two Outcomes:

	--Committed    : Changes made by transaction are persisted in the database.

	--Rolled Back  : Changes made by transaction are undone.

USE Nov25Sql

CREATE TABLE TranTable
(
	A INT PRIMARY KEY,
	B VARCHAR(30)
)

--Explicit Transactions : Has to be started explicitly with BEGIN TRAN and 
--needs to be COMMITED ot ROLLED BACK

BEGIN TRAN
	DECLARE @key INT, @value VARCHAR(30)
	SET @key = 1
	SET @value = '25Nov2021Sql'
	INSERT INTO TranTable
	VALUES(@key,@value)
COMMIT

SELECT * 
FROM TranTable

BEGIN TRAN
	DECLARE @key INT, @value VARCHAR(30)
	SET @key = 2
	SET @value = 'SQL Server'
	INSERT INTO TranTable
	VALUES(@key,@value)
ROLLBACK

SELECT *
FROM TranTable

--Implicit Transactions: Every query starts a new trasnaction.
SELECT * FROM TranTable

SET IMPLICIT_TRANSACTIONS ON

INSERT INTO TranTable
VALUES(2,'SQL Server')
COMMIT
INSERT INTO TranTable
VALUES(3, 'Git')
COMMIT

UPDATE TranTable
SET B='OOP and UML'
WHERE A=3
COMMIT

DELETE FROM TranTable
WHERE A=2
ROLLBACK

SELECT * FROM TranTable

SET IMPLICIT_TRANSACTIONS OFF

--SAVEPOINT
BEGIN TRAN
	INSERT INTO TranTable
	VALUES(4,'C#')
	INSERT INTO TranTable
	VALUES(5,'ASP.NET MVC Core')
	SAVE TRAN t1
	INSERT INTO TranTable
	VALUES(6,'DevOps')
	ROLLBACK TRAN t1
COMMIT TRAN

SELECT *
FROM TranTable

--Exception Handling in Transaction

EXEC SP_HELP 'Employees'
EXEC SP_HELP 'Departments'
SELECT * FROM Departments

CREATE PROCEDURE spEmpDept
(
	@departmentID INT,
	@departmentName VARCHAR(30)
)
AS
DECLARE @inserr INT,@maxerr INT = 0
BEGIN TRAN
	INSERT INTO Departments
	VALUES(@departmentID,@departmentName,NULL)

	INSERT INTO Employees
	VALUES('Unmukt','Chand','UP',75000,NULL,@departmentID)

	SET @inserr = @@error  
	IF @inserr > @maxerr  
		SET @maxerr = @inserr 
	IF @maxerr <> 0  
		BEGIN  
			ROLLBACK  
			PRINT 'Transaction rolled back'  
		END  
	ELSE  
		BEGIN  
			COMMIT  
			PRINT 'Transaction committed'  
		END  

EXEC spEmpDept 9,'Staffing'  --Works
EXEC spEmpDept 10,'Organizing'  --Fails as Unique Constraint in Employees table is violated

SELECT * FROM Employees
SELECT * FROM Departments
