package com.employeManagement.SpringJbdcEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("com/employeManagement/SpringJbdcEx/config.xml");

    	String insertQuery = "insert into emp values(?,?)";
    	String deleteQuery ="delete from emp where emp_id= ?";
    	String updateQuery ="update emp set emp_name =? where emp_id=?";

    	JdbcTemplate template = context.getBean("jdbcTemp",JdbcTemplate.class);


    	int row = template.update(insertQuery, 7,"Deep");
    	System.out.println(row+"affected");

    	int rowd = template.update(deleteQuery,6);
    	System.out.println(rowd+" deleted");

    	int rowu = template.update(updateQuery,"Bhushan",2);
    	System.out.println(rowu+" Updated");
    }
}
