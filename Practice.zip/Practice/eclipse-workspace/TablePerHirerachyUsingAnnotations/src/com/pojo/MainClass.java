package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {
	public static void main(String[] args) {

		Configuration conf= new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		Car car = new Car();
		car.setCar_name("Swift");
		EconomicalCar ecoCar = new EconomicalCar();
		ecoCar.setCar_name("honda city");
		ecoCar.setCar_price(5.4f);
		ecoCar.setCar_milage(19.5f);
		LuxiriousCar luxCar = new LuxiriousCar();
		luxCar.setCar_name("Range Rover");
		luxCar.setEngine_capacity(2500);
		luxCar.setCar_features("Fully Loaded");
		session.save(car);
		session.save(ecoCar);
		session.save(luxCar);
		trans.commit();
		System.out.println("Table created And data added");
	}
}
