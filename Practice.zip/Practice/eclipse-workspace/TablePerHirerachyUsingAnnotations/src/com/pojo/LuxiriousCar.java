package com.pojo;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue(value="LuxiriousCar")  
public class LuxiriousCar extends Car{

	
	private float engine_capacity;
	private String car_features;
	
	public float getEngine_capacity() {
		return engine_capacity;
	}
	public void setEngine_capacity(float engine_capacity) {
		this.engine_capacity = engine_capacity;
	}
	public String getCar_features() {
		return car_features;
	}
	public void setCar_features(String car_features) {
		this.car_features = car_features;
	}

	
}
