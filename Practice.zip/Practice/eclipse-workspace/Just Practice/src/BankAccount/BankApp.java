package BankAccount;

public class BankApp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class CustAcc{
	private int balance;
	
	//constructor
	public CustAcc(int balance) {
		this.balance=balance;
	}
	
	public boolean isEnoughBalance(int amount) {
		if(amount>=balance) {
			return true;
		}else {
			return false;
		}
	}
	
	public void currentBalance(int amount) {
		balance=balance-amount;
		System.out.println("");
	}
}
class Customer implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
}
