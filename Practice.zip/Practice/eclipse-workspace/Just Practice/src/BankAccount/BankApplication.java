package BankAccount;

import java.util.Scanner;

public class BankApplication {
public static void main(String[] args) {
CustAccount acc= new CustAccount(10000);
Customer cust1 = new Customer(acc, "John");
Customer cust2 = new Customer(acc, "Zanilia");
Thread t1 = new Thread(cust1);
Thread t2 = new Thread(cust2);
t1.start();
t2.start();
}
}
class CustAccount{
private int balance;
//
public CustAccount(int balance) {
this.balance = balance;
}
//this function check whether customer is having enough balance or not
public boolean isEnoughBalance(int amount) {
if(balance>=amount) {
return true;
}
else
return false;
}
//if amount is less than balance then customer can withdraw cash
//after withdrawing cash we will have to update current balance;
public void currentBalance(int amount) {
balance = balance-amount;
System.out.println("Withdraw Amount ="+amount);
System.out.println("Remaining Balance ="+balance);
}

}
class Customer implements Runnable{
CustAccount cstAcc;
private String name;
public Customer(CustAccount cstAcc,String name) {
this.cstAcc = cstAcc;
this.name=name;
}
@Override
public void run() {
synchronized (cstAcc) {
Scanner input = new Scanner(System.in);
System.out.println(name+" Enter the Amount to Withdraw");
int amt=input.nextInt();//12000
if(cstAcc.isEnoughBalance(amt)) {
cstAcc.currentBalance(amt);
System.out.println("Transaction completed");
}
else {
System.out.println("You don't have enough Balance");
}
}

}

}
