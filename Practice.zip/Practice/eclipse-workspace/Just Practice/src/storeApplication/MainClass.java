package storeApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=yogesh;user=sa;password=Password_123","sa","Password_123");
			System.out.println("connected to database");
			con.close();
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}

}
