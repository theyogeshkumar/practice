package polymorphism;

public class MethodOverridingEx {

	
	public static void main(String[] args) {
		
//		A obja= new A();
//		obja.meth1();
//		obja.meth2();
//		
//		B objb= new B();
//		objb.meth1();
//		objb.meth2();
		B obj=new B();
		obj.meth1(3);
		
	}

}
class A{
	public int a=23;
	public void meth1() {
		System.out.println("this is method 1 of class A");
	}
	
	public void meth2() {
		System.out.println("this is method 2 of class A");
	}
}
class B extends A{
	
	public int meth1(int a) {
//		System.out.println("this is method 1 of class B");
		return 1;
	}
	
	
	public void meth3() {
		System.out.println("this is method 3 of class B");
	}
	
	
	
	
}