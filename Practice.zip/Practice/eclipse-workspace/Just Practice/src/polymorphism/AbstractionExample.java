package polymorphism;

public class AbstractionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Child obj= new Child();
//		obj.engineCapacity();
//		obj.speed();
//		obj.getData();
//		Car.display();
		Abc obj1= new Abc();
		obj1.display();
		MyInterface.display1();
		
	}

}
abstract class Car{
	public abstract int engineCapacity();
	public abstract void speed();
	public static void display() {
		System.out.println("this is my display method in the abstract class");
	}
	public void getData() {
		System.out.println("enter Data");
	}
}

class Child extends Car{

	@Override
	public int engineCapacity() {
		System.out.println("this is engine capacity method.");
		return 0;
	}

	@Override
	public void speed() {
		// TODO Auto-generated method stub
		System.out.println("this is my speed method");
	}
	
}
interface MyInterface{
	void display();
	static void display1() {
		System.out.println("this is also my display 1 method in interface.");
	}
	default void display2() {
		System.out.println("this is also my display 2 method in interface.");
	}
}
class Abc implements MyInterface{

	@Override
	public void display() {
		System.out.println("this is my display method in interface and class Abc");
		
	}
	
}