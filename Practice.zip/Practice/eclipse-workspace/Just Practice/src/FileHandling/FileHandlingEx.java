package FileHandling;

import java.io.File;

public class FileHandlingEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file= new File("C:\\Users\\YogeshK3\\Desktop\\New folder\\yogesh");
		if(file.exists()) {
			System.out.println("Directory Already Exists.");
		}else {
			file.mkdir();
			System.out.println("Directory Created.");
		}
		
		
		File file2= new File("C:\\Users\\YogeshK3\\Desktop\\New folder\\yogesh\\MyData.txt");
		if(file2.exists()) {
			System.out.println("Already Exists.");
			System.out.println(file2.getName());
			System.out.println(file2.canRead());
			System.out.println(file2.canWrite());
			System.out.println(file2.canExecute());
			System.out.println(file2.getAbsolutePath());
			System.out.println(file2.getFreeSpace());
			System.out.println(file2.getTotalSpace());
		}else {
			System.out.println("File Not Found.");
		}
		
		
		//i want te list in specified directory
		System.out.println("files present in yogesh directory");
		System.out.println();
		File[] files= file.listFiles();
		for(int i=0;i<list.length;i++) {
			System.out.println(list[i]);
		}
	}

}
