package FileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ReadEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file= new File("C:\\Users\\YogeshK3\\Desktop\\New folder\\yogesh\\MyData.txt");
		
		try {
			FileReader frdr= new FileReader(file);
			int i=0;
			while((i=frdr.read())!=-1) {
				System.out.println((char)i);
			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

}
