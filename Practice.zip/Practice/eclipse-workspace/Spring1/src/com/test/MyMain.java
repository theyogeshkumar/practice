package com.test;

public class MyMain {

	public static void main(String[] args) {
		Student obj_student= new Student();
		obj_student.setStudent_id(1);
		obj_student.setStudent_name("yogesh kumar");
		obj_student.obj_teacher.setTeacher_name("Bhushan");
		obj_student.obj_teacher.setTeacher_id(126);
//		String subject =obj_student.obj_teacher.getSubject();
		System.out.println(obj_student.obj_teacher.getTeacher_name()+" - "+obj_student.obj_teacher.getSubject()+" - "+obj_student.getStudent_name()+"--" +obj_student.obj_teacher.getTeacher_id());
		
	}
}
