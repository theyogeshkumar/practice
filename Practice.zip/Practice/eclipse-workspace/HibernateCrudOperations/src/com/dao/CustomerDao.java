package com.dao;

//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerDao {

	public static Configuration getCustomerConfig() {
		Configuration conf=new Configuration();
		conf.configure("customer.cfg.xml");
		return conf;
	}
}
