package com.dao;

import org.hibernate.cfg.Configuration;

public class ProductDao {
	
	public static Configuration getProductConfig() {
		Configuration conf=new Configuration();
		conf.configure("product.cfg.xml");
		return conf;
	}
}
