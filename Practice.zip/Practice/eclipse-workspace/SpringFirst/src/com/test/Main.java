package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/test/config.xml");
		Helloworld obj= (Helloworld) context.getBean("helloworld");
		Helloworld obj1= (Helloworld) context.getBean("showtime");
		obj.display();
		obj1.displayTime();
		
	}
	
}
