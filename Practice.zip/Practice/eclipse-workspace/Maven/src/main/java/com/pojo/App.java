package com.pojo;

import java.util.Scanner;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
       Scanner sc= new Scanner(System.in);
    	Configuration conf= new Configuration();
    	conf.configure();
    	SessionFactory sf=conf.buildSessionFactory();
    	City city= new City();
    	System.out.println("Enter City Id:");
    	int city_id=sc.nextInt();
    	city.setCity_id(city_id);
    	System.out.println("Enter City Name:");
    	String city_name=sc.next();
    	city.setCity_name(city_name);
    	System.out.println();
    	Country country=new Country();
    	System.out.println("Enter Country Id:");
    	int country_id=sc.nextInt();
    	country.setCountry_id(country_id);
    	System.out.println("Enter Country Name:");
    	String country_name=sc.next();
    	country.setCountry_name(country_name);
    	
      	city.setCountry(country);
      	country.setCity(city);
    	
    	Session session=sf.openSession();
    	Transaction tran=session.beginTransaction();
    	session.save(city);
    	session.save(country);
    	tran.commit();
    	session.close();
    	sf.close();
    	System.out.println("done");
    }
}
