package Day6;

import java.util.Iterator;
import java.util.TreeSet;



public class TreeSetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<String> set= new TreeSet();
		set.add("yogesh");
		set.add("abhishek");
		set.add("saransh");
		set.add("arpit");
		Iterator itr = set.iterator();
		
		
	}

}
