package com.main;

import java.util.Scanner;



import com.model.AdminFunctions;



/**
 * Hello world!
 *
 */
public class App 
{
	static Scanner sc= new Scanner(System.in);
    public static void main( String[] args )
    {

//    	AdminFunctions adminFunc=new AdminFunctions();
    	login();
		
    }
    
    static void login() {
		// try with this id.
		String userName = "thesisodia";
		String password = "111";
		//

		System.out.print("Enter username:");
		String user_name = sc.next();
		System.out.print("Enter Pasword");
		String pass = sc.next();

		if (user_name.equals(userName) && pass.equals(password)) {
			System.out.println("Login Sucessfull.");
			System.out.println();
			AdminFunctions.menu();
		} else {
			System.out.println("Wrong Username or Password");
			
		}
	}
   

	
}
