package com.model;

public class Admin {

	private int question_no;
	private String question;
	public int getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(int question_no) {
		this.question_no = question_no;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public Admin(int question_no, String question) {
		super();
		this.question_no = question_no;
		this.question = question;
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Admin [question_no=" + question_no + ", question=" + question + "]";
	}
	
	
	
}
