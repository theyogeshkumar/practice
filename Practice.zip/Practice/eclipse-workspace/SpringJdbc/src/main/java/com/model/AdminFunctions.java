package com.model;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.AdminDao;
import com.main.App;

public class AdminFunctions {
	static Scanner sc = new Scanner(System.in);


	public static void menu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select The Operation");
		System.out.println();
		System.out.println("1. Add Question");
		System.out.println("2. Update Question");
		System.out.println("3. Delete Question");
		System.out.println("4. Add Student");
		System.out.println("5. Update Student");
		System.out.println("6. Delete Student");
		System.out.println("7. Get Single Students Details");
		System.out.println("8. Can get all Students Details");
		System.out.println("0. Exit");
		System.out.println();

//		app object
		App app = new App();

		int product = sc.nextInt();
		switch (product) {
		case 1:
			addQuestion();
			menu();
			break;
		case 2:
			updateQuestion();
			menu();
			break;
		case 3:
			deleteQuestion();
			menu();
			break;
		case 4:
			addStudent();
			menu();
			break;
		case 5:
			updateStudentInfo();
			menu();
			break;
		case 6:
			deleteStudentInfo();
			menu();
			break;
		case 7:
			getSingleStudent();
			menu();
			break;
		case 8:
			getAllStudent();
			menu();
			break;
		default:
			System.out.println("Wrong Input");
			break;
		}
	}

	public static void addQuestion() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
		Admin adm = new Admin();
		System.out.println("Enter Question Number");
		int question_no = sc.nextInt();
		adm.setQuestion_no(question_no);
		System.out.println("Type Question");
		String question = sc.next();
		adm.setQuestion(question);
		int result = admDao.insertQuestion(adm);
		System.out.println(result + " Rows Inserted");
	}

	public static void updateQuestion() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
//			updating ques
		Admin adm = new Admin();
		System.out.println("Enter Question Number");
		int question_no = sc.nextInt();
		adm.setQuestion_no(question_no);
		System.out.println("Type Question");
		String question = sc.next();
		adm.setQuestion(question);
		int result = admDao.updateQuestion(adm);
		System.out.println(result + " Rows Updated");
	}

	public static void deleteQuestion() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
		// delete
		Admin adm = new Admin();
		System.out.println("Enter Question Number");
		int question_no = sc.nextInt();
		adm.setQuestion_no(question_no);
	    int result = admDao.deleteQuestion(adm);
	    System.out.println(result+" Rows Deleted");
	}
	
	public static void addStudent() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
		Student student=new Student();
		System.out.println("Enter Student Roll Number");
		int stud_roll_no = sc.nextInt();
		student.setStud_roll_no(stud_roll_no);
		System.out.println("Enter Student Name");
		String stud_name = sc.next();
		student.setStud_name(stud_name);
		System.out.println("Enter Student Class");
		int stud_class=sc.nextInt();
		student.setStud_class(stud_class);
		System.out.println("Enter Percentage");
		int stud_marks=sc.nextInt();
		student.setMarks(stud_marks);
		int result = admDao.insertStudent(student);
		System.out.println(result + " Rows Inserted");
	}
	
	public static void updateStudentInfo() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
//			updating Sutdent
		Student student=new Student();
		System.out.println("Enter Students Roll Number");
		int stud_roll_no = sc.nextInt();
		student.setStud_roll_no(stud_roll_no);
		System.out.println("Enter Student Marks");
		int stud_marks = sc.nextInt();
		student.setMarks(stud_marks);
		int result = admDao.updateStudent(student);
		System.out.println(result + " Rows Updated");
	}
	
	public static void deleteStudentInfo() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
		// delete
		Student student= new Student();
		System.out.println("Enter Student Roll Number");
		int stud_roll_no = sc.nextInt();
		student.setStud_roll_no(stud_roll_no);
	    int result = admDao.deleteStudent(student);
	    System.out.println(result+" Rows Deleted");
	}
	
	public static void getSingleStudent() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
		// display only one Student
		System.out.println("Enter Student Roll Number");
		int stud_roll_no=sc.nextInt();
	     Student stud = admDao.getSingleStudent(stud_roll_no);
	     System.out.println("Student ID ="+stud.getStud_roll_no()+", Student Name ="+stud.getStud_name()+", Student Class ="+stud.getStud_class()+", Student Marks ="+stud.getMarks()+".");
	}
	
	public static void getAllStudent() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/main/config.xml");
		AdminDao admDao = context.getBean("admDao", AdminDao.class);
		// display all Student
	     List<Student> stud = admDao.getAllStudent();
	     for(Student e:stud) {
	     	System.out.println("Student ID ="+e.getStud_roll_no()+", Student Name ="+e.getStud_name()+", Student Class ="+e.getStud_class()+", Student Marks ="+e.getMarks()+".");	     
	     }
	}
}
