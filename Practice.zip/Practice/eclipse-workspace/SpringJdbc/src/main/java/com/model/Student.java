package com.model;

public class Student {

	private int stud_roll_no;
	private String stud_name;
	private int stud_class;
	private int marks;
	public int getStud_roll_no() {
		return stud_roll_no;
	}
	public void setStud_roll_no(int stud_roll_no) {
		this.stud_roll_no = stud_roll_no;
	}
	public String getStud_name() {
		return stud_name;
	}
	public void setStud_name(String stud_name) {
		this.stud_name = stud_name;
	}
	public int getStud_class() {
		return stud_class;
	}
	public void setStud_class(int stud_class) {
		this.stud_class = stud_class;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Student(int stud_roll_no, String stud_name, int stud_class, int marks) {
		super();
		this.stud_roll_no = stud_roll_no;
		this.stud_name = stud_name;
		this.stud_class = stud_class;
		this.marks = marks;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [stud_roll_no=" + stud_roll_no + ", stud_name=" + stud_name + ", stud_class=" + stud_class
				+ ", marks=" + marks + "]";
	}
	
	
}
