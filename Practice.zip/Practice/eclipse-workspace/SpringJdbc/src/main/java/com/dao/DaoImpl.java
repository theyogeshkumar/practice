package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.model.Admin;
import com.model.Student;

public class DaoImpl implements AdminDao{

	private JdbcTemplate jdbcTemplate;
	
	

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertQuestion(Admin adm) {
		
		String insertQuery="insert into Question values(?,?)";
		int row=this.jdbcTemplate.update(insertQuery,adm.getQuestion_no(),adm.getQuestion());
		return row;
	}

	public int updateQuestion(Admin adm) {
		String updateQuery = "update Question set question = ? where question_no = ?";
		int row= this.jdbcTemplate.update(updateQuery,adm.getQuestion(),adm.getQuestion_no());
		return row;
	}

	public int deleteQuestion(Admin adm) {
		String deleteQuery = "delete from Question where question_no = ?";
		int row= this.jdbcTemplate.update(deleteQuery,adm.getQuestion_no());
		return row;
	}

	public int insertStudent(Student stud) {
		String insertQuery ="insert into student values (?,?,?,?)";
		int row=this.jdbcTemplate.update(insertQuery,stud.getStud_roll_no(),stud.getStud_name(),stud.getStud_class(),stud.getMarks());
		return row;
	}

	public int updateStudent(Student stud) {
		String updateQuery = "update student set stud_marks = ? where stud_roll_no = ?";
		int row= this.jdbcTemplate.update(updateQuery,stud.getMarks(),stud.getStud_roll_no());
		return row;
	}

	public int deleteStudent(Student stud) {
		String deleteQuery = "delete from Student where stud_roll_no = ?";
		int row= this.jdbcTemplate.update(deleteQuery,stud.getStud_roll_no());
		return row;
	}

	public Student getSingleStudent(int stud_roll_no) {
		String selectOneStud ="select * from Student where stud_roll_no= ?";
		RowMapper<Student> rowMapper = new RowmapperImpl();
		Student stud = this.jdbcTemplate.queryForObject(selectOneStud,rowMapper,stud_roll_no);	
		return stud;
	}

	public List<Student> getAllStudent() {
		String selectAll = "select * from Student";
		List<Student> student= this.jdbcTemplate.query(selectAll, new RowmapperImpl());
		return student;
	}
	
	
}
