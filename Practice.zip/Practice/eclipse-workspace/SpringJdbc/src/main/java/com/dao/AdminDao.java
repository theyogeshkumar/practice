package com.dao;

import java.util.List;

import com.model.Admin;
import com.model.Student;


public interface AdminDao {

	public int insertQuestion(Admin adm);

	public int updateQuestion(Admin adm);

	public int deleteQuestion(Admin adm);
	
	public int insertStudent(Student stud);
	
	public int updateStudent(Student stud);
	
	public int deleteStudent(Student stud);

	public Student getSingleStudent(int stud_roll_no);

	public List<Student> getAllStudent();

}
