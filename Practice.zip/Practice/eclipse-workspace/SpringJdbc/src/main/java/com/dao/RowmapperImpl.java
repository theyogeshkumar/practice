package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.Student;

public class RowmapperImpl implements RowMapper<Student>{

	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Student stud=new Student();
		stud.setStud_roll_no(rs.getInt(1));
		stud.setStud_name(rs.getString(2));
		stud.setStud_class(rs.getInt(3));
		stud.setMarks(rs.getInt(4));
		return stud;
	}

}
