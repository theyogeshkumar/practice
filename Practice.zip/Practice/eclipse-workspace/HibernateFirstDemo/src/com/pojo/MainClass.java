package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		CustomerDetails obj = new CustomerDetails();
		Configuration conf=new Configuration();
		conf.configure();
		SessionFactory sf =conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		obj.setCname("Yogesh");
		obj.setCaddress("Delhi");
		session.save(obj);
		tran.commit();
		session.close();
		
		System.out.println("added Successfully");
	}

}
