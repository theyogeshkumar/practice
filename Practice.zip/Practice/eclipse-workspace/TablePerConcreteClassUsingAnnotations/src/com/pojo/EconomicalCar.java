package com.pojo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="newEcoCar1")
@AttributeOverrides({
		@AttributeOverride(name="car_id",column=@Column(name="car_id")),
		@AttributeOverride(name="car_name",column=@Column(name="car_name"))
})
public class EconomicalCar extends Car {

	private float car_price;
	private float car_milage;
	public float getCar_price() {
		return car_price;
	}
	public void setCar_price(float car_price) {
		this.car_price = car_price;
	}
	public float getCar_milage() {
		return car_milage;
	}
	public void setCar_milage(float car_milage) {
		this.car_milage = car_milage;
	}
	
}
