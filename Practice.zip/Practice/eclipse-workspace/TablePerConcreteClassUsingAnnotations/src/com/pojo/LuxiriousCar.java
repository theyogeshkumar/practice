package com.pojo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="newLuxCar1")
@AttributeOverrides({
		@AttributeOverride(name="car_id",column=@Column(name="car_id")),
		@AttributeOverride(name="car_name",column=@Column(name="car_name"))
})

public class LuxiriousCar extends Car{

	private float engine_capacity;
	private String car_features;
	
	public float getEngine_capacity() {
		return engine_capacity;
	}
	public void setEngine_capacity(float engine_capacity) {
		this.engine_capacity = engine_capacity;
	}
	public String getCar_features() {
		return car_features;
	}
	public void setCar_features(String car_features) {
		this.car_features = car_features;
	}

	
}
