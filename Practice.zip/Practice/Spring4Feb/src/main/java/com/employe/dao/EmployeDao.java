package com.employe.dao;

import java.util.List;

import com.employe.model.Emp;

public interface EmployeDao {

	public int insertEmployee(Emp emp);
	
	public int updateEmployee(Emp emp);
	
	public int deleteEmployee(Emp emp);
	
	public Emp getSingleEmployee(int emp_id);
	
	public List<Emp>  getAllEmployee();
	
}
