package com.employe.Spring4Feb;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.employe.dao.EmployeDao;
import com.employe.model.Emp;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/employe/Spring4Feb/config.xml");
		EmployeDao empDao = context.getBean("empDao", EmployeDao.class);

		// insert
//       Emp emp= new Emp();
//       emp.setEmp_id(5);
//       emp.setEmp_name("Rohtash Sisodia");
//       int result =empDao.insertEmployee(emp);
//       System.out.println(result+" rows inserted");

		// delete
//     Emp emp = new Emp();
//     emp.setEmp_id(2);
//     int result = empDao.deleteEmployee(emp);
//     System.out.println(result+" Rows Deleted");

		// Update
//     Emp emp = new Emp();
//     emp.setEmp_id(1);
//     emp.setEmp_name("Yogesh Sisodia");
//     int result = empDao.updateEmployee(emp);
//     System.out.println(result+" Rows Updated");

		// display only one employee
//     Emp emp = empDao.getSingleEmployee(6);
//     System.out.println(emp.getEmp_id()+"--"+emp.getEmp_name());

		// display all employees
     List<Emp> emp = empDao.getAllEmployee();
     for(Emp e:emp) {
     	System.out.println(e.getEmp_id()+"--"+e.getEmp_name());
     }
	}
}
