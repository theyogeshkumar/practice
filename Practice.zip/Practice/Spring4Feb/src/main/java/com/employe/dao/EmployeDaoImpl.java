package com.employe.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.employe.model.Emp;

public class EmployeDaoImpl  implements EmployeDao{
	//obj
	private JdbcTemplate jdbcTemplate;
	
	//getter and setter
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertEmployee(Emp emp) {
			String insertQuery ="insert into emp values (?,?)";
			int row=this.jdbcTemplate.update(insertQuery,emp.getEmp_id(),emp.getEmp_name());
			return row;
	}

	public int updateEmployee(Emp emp) {
		String updateQuery = "update emp set emp_name = ? where emp_id = ?";
		int row= this.jdbcTemplate.update(updateQuery,emp.getEmp_name(),emp.getEmp_id());
		return row;
	}

	public int deleteEmployee(Emp emp) {
		String deleteQuery = "delete from emp where emp_id = ?";
		int row= this.jdbcTemplate.update(deleteQuery,emp.getEmp_id());
		return row;
	}

	public Emp getSingleEmployee(int emp_id) {
		String selectOneEmp ="select * from emp where emp_id= ?";
		RowMapper<Emp> rowMapper = new RowMapperImpl();
		Emp emp = this.jdbcTemplate.queryForObject(selectOneEmp,rowMapper,emp_id);	
		return emp;
	}

	public List<Emp> getAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
}
