package com.databaseDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

//Preared Statements

public class Demo2 {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Scanner input = new Scanner(System.in);
		try {
			// ---Insert data using prepared statement
//			System.out.println("Enter the ID of Product");
//			int pid=input.nextInt();
//			System.out.println("Enter the Name of Product");
//			String pname= input.next();
//			System.out.println("Enter the Price of Product");
//			int pprice = input.nextInt();
//			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ABCStore;user=sa;password=password_123");
//			PreparedStatement pstmt = con.prepareStatement("insert into Product values(?,?,?)");
//			pstmt.setInt(1, pid);
//			pstmt.setString(2, pname);
//			pstmt.setInt(3, pprice);
//			pstmt.executeUpdate();
//			System.out.println("Product Added successfully");

			// ---Update data using prepared
//			System.out.println("Enter the ID of Product");
//			int pid=input.nextInt();
//			System.out.println("Enter the Price of Product");
//			int pprice = input.nextInt();
//			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ABCStore;user=sa;password=password_123");
//			PreparedStatement pstmt = con.prepareStatement("update Product set prod_price=? where prod_id=?");
//			//1,2 this is going to represent the sequence of the parameter in prepared statement.
//			pstmt.setInt(1, pprice);
//			pstmt.setInt(2, pid);
//			pstmt.executeUpdate();
//			System.out.println("Product Updated");

			// Select * from Table where id =10;
			System.out.println("Enter the ID of Product");
			int pid = input.nextInt();
			Connection con = DriverManager.getConnection(
					"jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ABCStore;user=sa;password=password_123");
			PreparedStatement pstmt = con.prepareStatement("select * from Product where prod_id=?");
			pstmt.setInt(1, pid);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("Product ID -" + rs.getInt(1) + "Product Name -" + rs.getString(2)
						+ "Product Price -" + rs.getInt(3));
			}

			System.out.println("Done");
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());

		}

	}

}

//Statement stmt = con.createStatement();
//stmt.executeUpdate("insert into Product values("+pid+","+"'"+pname+"'"+","+pprice+")");