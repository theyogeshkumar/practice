package com.databaseDemo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Scanner;

public class CallableStatementEx {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		try {
			Connection con = DriverManager.getConnection(
					"jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ABCStore;user=sa;password=password_123");
			CallableStatement cstmt = con.prepareCall("{call TestProc}");
			ResultSet rs = cstmt.executeQuery();
			while (rs.next()) {
				System.out.println("Product Name -" + rs.getString(1)
						+ "Product Price -" + rs.getInt(2));
			}
			con.close();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}

}
