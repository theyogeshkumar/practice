package com.databaseDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//Statement

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException  {
		//Step 1. Register driver
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		//Step 2, Create connection
		try {
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ABCStore;user=sa;password=password_123");
//			insert into Product values(1, 'Iphone',50000)
			//step 3.
			Statement stmt = con.createStatement();
			//Step 4
			//Inserting data in table----------------------------------------
//			stmt.executeUpdate("insert into Product values (2,'Vivo',50000)");
//			System.out.println("Data Added Successfully");
			//for inserting, deleting and updating data in database
			//we have to use method executeUpdate()
			//but for getting data from database we have a method that is
			//executeQuery  - return (Result set)
			
			
			//Update the data 
//			int i =stmt.executeUpdate("Update Product set prod_price=30000 where prod_id=2");
//			System.out.println(i+"Product updated");
			
			
			//Delete the product
//			stmt.executeUpdate("delete from Product where prod_id=2");
//			System.out.println("Product Deleted");
			
			
			//SQL select is going to return us Table 
			//We have ResultSet 
			
			ResultSet rs = stmt.executeQuery("select * from Product") ; //"select * from Product"
			while(rs.next()) {
				System.out.println("Product ID -"+rs.getInt(1)+
						"Product Name -"+rs.getString(2)+"Product Price -"+rs.getInt(3));
			}
			//Step 5
			con.close();
		} catch (SQLException e) {
			
		}
		
		

	}

}
