package com.databaseDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CommitRollBackEx {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Scanner input = new Scanner(System.in);
		try {
			// ---Insert data using prepared statement
			System.out.println("Enter the ID of Product");
			int pid=input.nextInt();
			System.out.println("Enter the Name of Product");
			String pname= input.next();
			System.out.println("Enter the Price of Product");
			int pprice = input.nextInt();
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ABCStore;user=sa;password=password_123");
			//set the mode for transaction
			//very important
			con.setAutoCommit(false);
			PreparedStatement pstmt = con.prepareStatement("insert into Product values(?,?,?)");
			pstmt.setInt(1, pid);
			pstmt.setString(2, pname);
			pstmt.setInt(3, pprice);
			pstmt.executeUpdate();
			System.out.println("Product Added successfully");

			String areYouSure="Yes";
			if(areYouSure.equals("Yes")) {
				con.commit();
				System.out.println("Data Added ");
			}else {
				con.rollback();
				System.out.println("Operation Rolled Back");
			}	
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());

		}

	}

	}


