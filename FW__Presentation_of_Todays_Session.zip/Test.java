package com.java;

import java.util.Date;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

@FunctionalInterface
interface Printable
{
	public void print();
}



public class Test {
	
	public static void newMethod()
	{
		 System.out.println("This is method reference example");
	}

	public static void main(String[] args) {
		
		
		Printable methodRef=Test::newMethod;
		
		
		Printable p=()-> System.out.println("hello");
		p.print();
		
		
		
		
		
		
		
		
		Predicate<Integer> per= i-> i%2==0 ;
		System.out.println(per.test(7));
		
		
		Predicate<String> per2= str ->(str.length()>7);
		System.out.println(per2.test("Bhawanaaa"));
		
		
		Function<String, Integer> fun=   str -> str.length();
		System.out.println(fun.apply("Bhawana"));
		
		Function<Integer, Integer> fun2=   I -> I*I;
		System.out.println(fun2.apply(8));
		
		
		Supplier<Date> date= ()->new Date();
		System.out.println(date.get());
		
		
		Supplier<User> us1=()-> new User("Anu", "US");
		System.out.println(us1.get());
		
		
		
		BiPredicate<Integer, Integer> bi=(a,b)->(a+b)%2==0;
		System.out.println(bi.test(12, 10));
		
		BiFunction<Integer, Integer, Integer> bifun=(a,b) -> a*b;
		System.out.println(bifun.apply(12, 12));
		
		
		BiConsumer<String , String> con=(str1,str2)-> System.out.println(str1+str2);
		con.accept("ABC", "DEF");
		
		
	}

}
