package com.java;



 class Product {
	
	private String str;

	public Product(String str) {
		this.str = str;
	}
	
	

}
interface Interf
{
	public Product get(String str);
}

class Sample
{
	
	public static void main(String[] args) {
		Interf in= str -> new Product(str);
		
		
		Interf in1=Product::new;
	}
}