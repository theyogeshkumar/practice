package com.java;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class Demo {

	public static void main(String[] args) {
     User u1=new User("Anna", "Paris");
     User u2=new User("Alex", "Paris");
     User u3=new User("David", "Paris");
     User u4=new User("Amit", "Paris");
     User u5=new User("Yui", "Paris");
     
     List<User> userlist=List.of(u1,u2,u3,u4,u5);
     
Function<User, String> fun=(User user)  -> user.getName();
	for(User us: userlist)
		System.out.println(fun.apply(us));
	}
	
	Consumer<User> con= (User user) ->System.out.println(user.name);

}
