package com.pojo;


import java.util.List;

import java.util.Scanner;

import javax.transaction.Transactional;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.AdminDao;
import com.dao.AdminDaoImpl;
import com.main.App;
import com.model.AdminFunctions;

@Transactional
public class AdminFunctions {
	static Scanner sc = new Scanner(System.in);

	static void login() {
		// try with this id.
		String userName = "thesisodia";
		String password = "111";
		//

		System.out.print("Enter username:  (try this:thesisodia)");
		String user_name = sc.next();
		System.out.print("Enter Pasword    (try this:111)");
		String pass = sc.next();
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        
        
		

		if (user_name.equals(userName) && pass.equals(password)) {
			System.out.println("Login Sucessfull.");
			System.out.println();
			AdminFunctions.menu();
		} else {
			System.out.println("Wrong Username or Password");

		}
	}

	public static void menu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select The Operation");
		System.out.println();
		System.out.println("1. Add Question");
		System.out.println("2. Update Question");
		System.out.println("3. Delete Question");
		System.out.println("4. Add Student");
		System.out.println("5. Update Student");
		System.out.println("6. Delete Student");
		System.out.println("7. Get Single Students Details");
		System.out.println("8. Can get all Students Details");
		System.out.println("9. Can get all Questions Details");
		System.out.println("0. Exit");
		System.out.println();

//		app object
		App app = new App();

		int product = sc.nextInt();
		switch (product) {
		case 1:
			addQuestion();
			menu();
			break;
		case 2:
			updateQuestion();
			menu();
			break;
		case 3:
			deleteQuestion();
			menu();
			break;
		case 4:
			addStudent();
			menu();
			break;
		case 5:
			updateStudentInfo();
			menu();
			break;
		case 6:
			deleteStudentInfo();
			menu();
			break;
		case 7:
			getSingleStudent();
			menu();
			break;
		case 8:
			getAllStudent();
			menu();
			break;
		case 9:
			getAllQuestions();
			menu();
			break;
		case 0:
			System.out.println("Thankyou for using our Application.");
			System.exit(0);
			break;
		default:
			System.out.println("Wrong Input");
			break;
		}
	}

	public static void addQuestion() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        
//        System.out.println("Enter the Question No.");
//        int ques_no=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the Question   (use _ instead of space)");
        String ques=sc.nextLine();
        
        Admin adm= new Admin();
//        adm.setQuestion_no(ques_no);
        adm.setQuestion(ques);
        
        adminDao.insertQuestion(adm);
        System.out.println("Question Addedin the table.");
	}

	public static void updateQuestion() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        
        System.out.println("Enter Question Number");
		int question_no = sc.nextInt();
		System.out.println("Type Question");
		sc.nextLine();
		String question = sc.nextLine();
        Admin adm= new Admin();
        adm.setQuestion_no(question_no);
        adm.setQuestion(question);
        
        adminDao.updateQuestion(adm);
	}

	public static void deleteQuestion() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        System.out.println("Enter Question Number");
		int question_no = sc.nextInt();
        adminDao.deleteQuestion(question_no);
	}

	public static void addStudent() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        
//        System.out.println("Enter Student Roll Number");
//		int stud_roll_no = sc.nextInt();
		System.out.println("Enter Student Name");
		sc.nextLine();
		String stud_name = sc.nextLine();
		System.out.println("Enter Student Class");
		int stud_class=sc.nextInt();
		System.out.println("Enter Percentage");
		int stud_marks=sc.nextInt();
        
        Student student=new Student();
//        student.setStud_roll_no(stud_roll_no);
        student.setStud_name(stud_name);
        student.setStud_class(stud_class);
        student.setMarks(stud_marks);
        int row=adminDao.insertStudent(student);
        System.out.println(row+" Row Inserted");
	}

	public static void updateStudentInfo() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);

        System.out.println("Enter Students Roll Number");
		int stud_roll_no = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Students Name");
		String stud_name=sc.nextLine();
		System.out.println("Enter Students Class");
		int stud_class=sc.nextInt();
		System.out.println("Enter Student Marks");
		int stud_marks = sc.nextInt();
        
        Student student=new Student();
        student.setStud_roll_no(stud_roll_no);
        student.setStud_name(stud_name);
        student.setStud_class(stud_class);
        student.setMarks(stud_marks);
        adminDao.updateStudent(student);
	}

	public static void deleteStudentInfo() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        System.out.println("Enter Student Roll Number");
		int stud_roll_no = sc.nextInt();
        
        adminDao.deleteStudent(stud_roll_no);
	}

	public static void getSingleStudent() {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/pojo/config.xml");
        AdminDaoImpl adminDao=context.getBean("adminDao",AdminDaoImpl.class);
        
        System.out.println("Enter Student Roll Number");
		int stud_roll_no=sc.nextInt();
        
        Student stud=adminDao.getSingleStudent(stud_roll_no);
        if(stud==null) {
        	System.out.println("No data available");
        }else {
        System.out.println("Roll no.="+stud.getStud_roll_no()+"  -  Name="+stud.getStud_name()+"  -  Class="+stud.getStud_class()+"  -  Marks="+stud.getMarks());
        }
        }

	public static void getAllStudent() {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/pojo/config.xml");
		AdminDaoImpl adminDao = context.getBean("adminDao", AdminDaoImpl.class);

		List<Student> list = adminDao.getAllStudent();
		if(list.size()==0) {
			System.out.println("No data Available");
		}else {
		for (Student stud : list) {
			System.out.println("Roll no.=" + stud.getStud_roll_no() + "  -  Name=" + stud.getStud_name() + "  -  Class="
					+ stud.getStud_class() + "  -  Marks=" + stud.getMarks());
		}
		}
	}
		
		public static void getAllQuestions() {
			ApplicationContext context = new ClassPathXmlApplicationContext("com/pojo/config.xml");
			AdminDaoImpl adminDao = context.getBean("adminDao", AdminDaoImpl.class);

			List<Admin> list = adminDao.getAllQuestions();
			if(list.size()==0) {
				System.out.println("No Data Available.");
			}else {
			for (Admin ques : list) {
				System.out.println("Question no.=" + ques.getQuestion_no() + "  -  Question =" + ques.getQuestion());
			}
			}
	}
}
