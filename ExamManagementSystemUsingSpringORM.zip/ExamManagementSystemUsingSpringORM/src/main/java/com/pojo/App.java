package com.pojo;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.AdminDaoImpl;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/pojo/config.xml");
		AdminDaoImpl adminDao = context.getBean("adminDao", AdminDaoImpl.class);

		AdminFunctions.login();

	}
}
