package com.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student_Table")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Student_Roll_No")
	private int stud_roll_no;
	@Column(name="Student_Name")
	private String stud_name;
	@Column(name="Student_Class")
	private int stud_class;
	@Column(name="Student_Marks")
	private int marks;
	
	public int getStud_roll_no() {
		return stud_roll_no;
	}
	public void setStud_roll_no(int stud_roll_no) {
		this.stud_roll_no = stud_roll_no;
	}
	public String getStud_name() {
		return stud_name;
	}
	public void setStud_name(String stud_name) {
		this.stud_name = stud_name;
	}
	public int getStud_class() {
		return stud_class;
	}
	public void setStud_class(int stud_class) {
		this.stud_class = stud_class;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Student(int stud_roll_no, String stud_name, int stud_class, int marks) {
		super();
		this.stud_roll_no = stud_roll_no;
		this.stud_name = stud_name;
		this.stud_class = stud_class;
		this.marks = marks;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [stud_roll_no=" + stud_roll_no + ", stud_name=" + stud_name + ", stud_class=" + stud_class
				+ ", marks=" + marks + "]";
	}
	
	
}
