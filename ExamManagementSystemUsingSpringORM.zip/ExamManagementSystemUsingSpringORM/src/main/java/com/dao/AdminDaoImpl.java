package com.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.pojo.Student;
import com.pojo.Admin;

@Transactional
public class AdminDaoImpl {

	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public int insertQuestion(Admin adm) {
		int row = (Integer) this.hibernateTemplate.save(adm);
		return row;
	}

	public void updateQuestion(Admin adm) {
		this.hibernateTemplate.update(adm);
		System.out.println("Updated");

	}

	public void deleteQuestion(int adm) {
		Admin admin = this.hibernateTemplate.get(Admin.class, adm);
		try {
			this.hibernateTemplate.delete(admin);
			System.out.println("Question Deleted");
		} catch (IllegalArgumentException ex) {
			System.out.println("Already Empty");
		}
	}

	public int insertStudent(Student stud) {
		int row = (Integer) this.hibernateTemplate.save(stud);
		return row;
	}

	public void updateStudent(Student stud) {
		this.hibernateTemplate.update(stud);
		System.out.println("Updated");
	}

	public void deleteStudent(int stud) {
		Student student = this.hibernateTemplate.get(Student.class, stud);
		try {
			this.hibernateTemplate.delete(student);
			System.out.println("Student Deleted");
		} catch (IllegalArgumentException ex) {
			System.out.println("Already Empty");
		}
	}

	public Student getSingleStudent(int stud_roll_no) {
		Student stud = this.hibernateTemplate.get(Student.class, stud_roll_no);

		return stud;
	}

	public List<Student> getAllStudent() {
		List<Student> list=this.hibernateTemplate.loadAll(Student.class);
		return list;

	}
	
	public List<Admin> getAllQuestions() {
		List<Admin> list=this.hibernateTemplate.loadAll(Admin.class);
		return list;

	}
	
}
