package com.student;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.service.StudentOperation;
import com.student.model.Student;



@Controller
public class formController {
	@Autowired
	private StudentOperation studentOperation;
	
	@RequestMapping("/regform")
	public String registerFrom() {
		return "signup";
	}
	@RequestMapping(path="/doregistration",method=RequestMethod.POST)
	public String doRegistration(@ModelAttribute Student student,Model model)
	{	
		this.studentOperation.createStudent(student);
		return "regDone";
		
	}
	
}

//@RequestMapping(path="/doregistration",method=RequestMethod.POST)
//public String doRegistration(HttpServletRequest request) {
//	String uname =request.getParameter("uname");
//	String email =request.getParameter("email");
//	String password =request.getParameter("password");
//	System.out.println(uname+"-"+email+"-"+password);
//	
//	return "regDone";
//	
//}



//@RequestMapping(path="/doregistration",method=RequestMethod.POST)
//public String doRegistration(@RequestParam("uname") String uname,
//		@RequestParam("email") String email,
//		@RequestParam("password") String pass,
//		Model model)
//{
//	
//	Student student = new Student();
//	student.setUname(uname);
//	student.setEmail(email);
//	student.setPassword(pass);
//	model.addAttribute("student",student);
//	
////	model.addAttribute("uname",uname);
////	model.addAttribute("email",email);
////	model.addAttribute("password",pass);
//	return "regDone";
//	
//}
