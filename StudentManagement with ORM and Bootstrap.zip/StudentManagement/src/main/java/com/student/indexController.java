package com.student;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class indexController {

	//handler method
	@RequestMapping("/")
	public String getIndex() {
		return "index";
	}
	
	@RequestMapping("/home")
	public String home(Model model) {
		int student_id= 101;
		String student_name ="Rakshit";
		
		List<String> subjects = new ArrayList();
		subjects.add("English");
		subjects.add("History");
		subjects.add("Geography");
		
		model.addAttribute("stud_id",student_id);
		model.addAttribute("stud_name",student_name);
		model.addAttribute("stud_subjects",subjects);		
		return "home";
	}
	
	@RequestMapping(path="/service", method=RequestMethod.GET)
	public ModelAndView services() {
		ModelAndView modelAndView = new ModelAndView();
		int student_id= 101;
		String student_name ="Rakshit";
		
		List<String> subjects = new ArrayList();
		subjects.add("English");
		subjects.add("History");
		subjects.add("Geography");
		
		modelAndView.addObject("stud_id",student_id);
		modelAndView.addObject("stud_name",student_name);
		modelAndView.addObject("stud_subjects",subjects);
		modelAndView.setViewName("service");
		
		
		return modelAndView;
	}
}
