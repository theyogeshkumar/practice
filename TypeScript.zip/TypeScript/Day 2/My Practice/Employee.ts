interface IEmployee {
    employeeId:number;
    firstName:string;
    lastName:string;
    contactNo:number;
    email:string;
    isActive:boolean;
    displayDetails():void;
}

class Employee {
    employeeId:number;
    firstName:string;
    lastName:string;
    contactNo:number;
    email:string;
    isActive:boolean;


    constructor(employeeId:number,firstName:string,lastName:string,contactNo:number,email:string,isActive:boolean) {
        this.employeeId=employeeId;
        this.firstName=firstName;
        this.lastName=lastName;
        this.contactNo=contactNo;
        this.email=email;
        this.isActive=isActive;        
    }

    displayDetails(){
        console.log(this.employeeId);
        console.log(this.firstName);
        console.log(this.lastName);
        console.log(this.contactNo);
        console.log(this.email);
        console.log(this.isActive);
    }
}

let emp=new Employee(1,"Yogesh","Kumar",80237242,"yogesh@gmail.com",true);
emp.displayDetails();