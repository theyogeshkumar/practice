class Customer
{
    private _customerId:number;
    firstName:String;
    lastName:String;
    contactNo:number;
    email:String;
    isPrevillaged:boolean;

    constructor(customerId:number,firstName:String,lastName:String,contactNo:number,email:String,isPrevillaged:boolean){
        this._customerId=customerId;
        this.firstName=firstName;
        this.lastName=lastName;
        this.contactNo=contactNo;
        this.email=email;
        this.isPrevillaged=isPrevillaged;
    }

    public get customerId() : number {
        return this._customerId;
    }
    
    public set customerId(custId:number) {
        this._customerId = custId;
    }

    displayDetails():void {
        // console.log("Customer Id = "+this.customerId);
        console.log("First Name = "+this.firstName);
        console.log("Last Name = "+this.lastName); 
        console.log("Contact NO. = "+this.contactNo);
        console.log("Email Id = "+this.email);
        console.log("IsPrevillaged = "+this.isPrevillaged);
        
        
    }   
    
    //2 Array
    // customers:Array<Customer>;

    // addCustomer():string{
    //     let cust3=new Customer(1,"Saransh","Balyan",9865982311,"sarans@gmail.com",true);
    //     return "c"
    // }

    
     
    
    
    
    

}


let cust=new Customer(44,"Yogesh","Kumar",129368232,"yogesh123gmail.com",true);
cust.customerId=12;
console.log("Customer Id = "+cust.customerId);
cust.displayDetails();

console.log();




let cust2=new Customer(54,"Abhishek","Mahto",9833294627,"abhishek1299@gmail.com",false);
cust2.customerId=14;
console.log("Customer Id = "+cust2.customerId);
cust2.displayDetails();

//2
let customer: Customer[] = [cust, cust2];
console.log(...customer);
