var Customer = /** @class */ (function () {
    function Customer(customerId, firstName, lastName, contactNo, email, isPrevillaged) {
        this._customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNo = contactNo;
        this.email = email;
        this.isPrevillaged = isPrevillaged;
    }
    Object.defineProperty(Customer.prototype, "customerId", {
        get: function () {
            return this._customerId;
        },
        set: function (custId) {
            this._customerId = custId;
        },
        enumerable: false,
        configurable: true
    });
    Customer.prototype.displayDetails = function () {
        // console.log("Customer Id = "+this.customerId);
        console.log("First Name = " + this.firstName);
        console.log("Last Name = " + this.lastName);
        console.log("Contact NO. = " + this.contactNo);
        console.log("Email Id = " + this.email);
        console.log("IsPrevillaged = " + this.isPrevillaged);
    };
    return Customer;
}());
var cust = new Customer(44, "Yogesh", "Kumar", 129368232, "yogesh123gmail.com", true);
cust.customerId = 12;
console.log("Customer Id = " + cust.customerId);
cust.displayDetails();
console.log();
var cust2 = new Customer(54, "Abhishek", "Mahto", 9833294627, "abhishek1299@gmail.com", false);
cust2.customerId = 14;
console.log("Customer Id = " + cust2.customerId);
cust2.displayDetails();
//2
var customer = [cust, cust2];
console.log.apply(console, customer);
