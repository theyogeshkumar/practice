var Employee = /** @class */ (function () {
    function Employee(employeeId, firstName, lastName, contactNo, email, isActive) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNo = contactNo;
        this.email = email;
        this.isActive = isActive;
    }
    Employee.prototype.displayDetails = function () {
        console.log(this.employeeId);
        console.log(this.firstName);
        console.log(this.lastName);
        console.log(this.contactNo);
        console.log(this.email);
        console.log(this.isActive);
    };
    return Employee;
}());
var emp = new Employee(1, "Yogesh", "Kumar", 80237242, "yogesh@gmail.com", true);
emp.displayDetails();
