let fruits:Array<string>;
fruits=["Apple","Banana","Mango"]
for(var index in fruits)
{
    console.log(fruits[index]);
}

let ids:Array<number>;
ids = [1,2,3,4,5];
for(var number=0;number<ids.length;number++)
{
    console.log(ids[number]);
}


