let employeeId:number = 1001;
let firstName:string = "Sachin";
let lastName:string = "Tendulkar";
let maritalStatus:boolean = true;
let remuneration = 500000.789;      //Type Inference. remuneration is of type number
//remuneration = "Hello World";     //Error
let foo:any = 1900;
console.log("Numeric Foo");
console.log(foo);
foo = "Hello World";
console.log("Alphabetic Foo");
console.log(foo);


console.log(employeeId);
console.log(firstName);
console.log(lastName);
console.log(maritalStatus);
console.log(remuneration);