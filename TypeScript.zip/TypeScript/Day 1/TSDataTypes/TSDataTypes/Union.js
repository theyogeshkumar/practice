var code;
code = 123;
console.log(code);
code = "ABC";
console.log(code);
