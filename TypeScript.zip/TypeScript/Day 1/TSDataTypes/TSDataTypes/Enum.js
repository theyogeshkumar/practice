var PrintMedia;
(function (PrintMedia) {
    PrintMedia[PrintMedia["Newspaper"] = 1] = "Newspaper";
    PrintMedia[PrintMedia["Newsletter"] = 5] = "Newsletter";
    PrintMedia[PrintMedia["Magazine"] = 9] = "Magazine";
    PrintMedia[PrintMedia["Book"] = 10] = "Book";
})(PrintMedia || (PrintMedia = {}));
console.log(PrintMedia);
console.log(PrintMedia.Magazine);
console.log(PrintMedia.Newsletter);
console.log(PrintMedia.Magazine | PrintMedia.Newsletter);
