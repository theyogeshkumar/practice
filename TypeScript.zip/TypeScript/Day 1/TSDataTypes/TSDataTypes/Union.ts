let code: (string|number);
code = 123;
console.log(code);
code = "ABC";
console.log(code);