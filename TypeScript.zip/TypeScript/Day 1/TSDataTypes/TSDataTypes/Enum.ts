enum PrintMedia
{
    Newspaper = 1,
    Newsletter = 5,
    Magazine = 9,
    Book = 10
}
console.log(PrintMedia);
console.log(PrintMedia.Magazine);
console.log(PrintMedia.Newsletter);
console.log(PrintMedia.Magazine|PrintMedia.Newsletter);