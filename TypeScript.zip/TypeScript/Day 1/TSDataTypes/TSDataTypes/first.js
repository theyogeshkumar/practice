var employeeId = 1001;
var firstName = "Sachin";
var lastName = "Tendulkar";
var maritalStatus = true;
var remuneration = 500000.789; //Type Inference. remuneration is of type number
//remuneration = "Hello World";     //Error
var foo = 1900;
console.log("Numeric Foo");
console.log(foo);
foo = "Hello World";
console.log("Alphabetic Foo");
console.log(foo);
console.log(employeeId);
console.log(firstName);
console.log(lastName);
console.log(maritalStatus);
console.log(remuneration);
