function AddNumbers(firstNumber, secondNumner) {
    return firstNumber + secondNumner;
}
var sum = AddNumbers(10, 20);
console.log('Addition is ' + sum);
var Addition = function (firstNumber, secondNumner) {
    return firstNumber + secondNumner;
};
sum = Addition(700, 250);
console.log('Addition using anonymous function is ' + sum);
var summation = function (firstNumber, secondNumner) {
    return firstNumber + secondNumner;
};
sum = summation(1050, 290);
console.log('Addition using arrow function is ' + sum);
var Print = function () { return console.log("Hello TypeScript"); };
Print(); //Output: Hello TypeScript
//curly braces and return keyword are optional if function contains only one statement
summation = function (firstNumber, secondNumner) { return firstNumber + secondNumner; };
sum = summation(150, 290);
console.log('Addition using arrow function is ' + sum);
var Employee = /** @class */ (function () {
    function Employee(code, name) {
        var _this = this;
        this.display = function () { return console.log(_this.empCode + ' ' + _this.empName); };
        this.empName = name;
        this.empCode = code;
    }
    return Employee;
}());
var emp = new Employee(1, 'Ram');
emp.display();
