function multiply(...args: number[]){
    let answer:number = 1;
    for(let arg:number = 0;arg<args.length;arg++) {
        answer *= args[arg];
    }
    return answer;
}
let digits:number[] = [10,5,7];
let multiplication = multiply(...digits);
console.log('Multiplication using Rest & Spread Operator '+multiplication);
digits = [10,5,7,2];
multiplication = multiply(...digits);
console.log('Multiplication using Rest & Spread Operator '+multiplication);