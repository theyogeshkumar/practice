function multiply() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    var answer = 1;
    for (var arg = 0; arg < args.length; arg++) {
        answer *= args[arg];
    }
    return answer;
}
var digits = [10, 5, 7];
var multiplication = multiply.apply(void 0, digits);
console.log('Multiplication using Rest & Spread Operator ' + multiplication);
digits = [10, 5, 7, 2];
multiplication = multiply.apply(void 0, digits);
console.log('Multiplication using Rest & Spread Operator ' + multiplication);
