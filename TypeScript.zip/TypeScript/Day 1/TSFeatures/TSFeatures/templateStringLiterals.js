var World = "world";
var Greeting = "hello ".concat(World);
console.log(Greeting);
