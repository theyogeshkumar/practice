function AddNumbers(firstNumber:number,secondNumner:number) {
    return firstNumber + secondNumner;
}

let sum:number = AddNumbers(10,20);
console.log('Addition is '+sum);

let Addition = function(firstNumber:number,secondNumner:number) {
    return firstNumber + secondNumner;
}

sum = Addition(700,250);
console.log('Addition using anonymous function is '+sum);

let summation = (firstNumber:number,secondNumner:number):number => {
    return firstNumber + secondNumner;
}

sum = summation(1050,290);
console.log('Addition using arrow function is '+sum);

let Print = () => console.log("Hello TypeScript");

Print(); //Output: Hello TypeScript

//curly braces and return keyword are optional if function contains only one statement
summation = (firstNumber:number,secondNumner:number):number => firstNumber + secondNumner;
sum = summation(150,290);
console.log('Addition using arrow function is '+sum);

class Employee {
    empCode: number;
    empName: string;

    constructor(code: number, name: string) {
        this.empName = name;
        this.empCode = code;
    }

    display = () => console.log(this.empCode +' ' + this.empName)
}
let emp = new Employee(1, 'Ram');
emp.display();