/*
Destructuring
Destructuring assignment is a syntax that allows you to assign object properties or array items as variables. 
This can greatly reduce the lines of code necessary to manipulate data in these structures. 
There are two types of destructuring: Object destructuring and Array destructuring.
*/

/*
Object Destructuring
Object destructuring allows you to create new variables using an object property as the value.
*/

const note = {
    id: 1,
    title: 'My first note',
    date: '01/01/1970',
}
const { id, title, date } = note;
console.log(id);
console.log(title);
console.log(date);

/*
Array Destructuring
Array destructuring allows you to create new variables using an array item as a value.
*/
const doj = ['2005', '12', '01'];
const[year, month, day] = doj;
console.log(year);
console.log(month);
console.log(day);

const[yoj,,dateOfJoining] = doj;
console.log(yoj);
console.log(dateOfJoining);