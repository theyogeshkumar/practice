/*
Destructuring
Destructuring assignment is a syntax that allows you to assign object properties or array items as variables.
This can greatly reduce the lines of code necessary to manipulate data in these structures.
There are two types of destructuring: Object destructuring and Array destructuring.
*/
/*
Object Destructuring
Object destructuring allows you to create new variables using an object property as the value.
*/
var note = {
    id: 1,
    title: 'My first note',
    date: '01/01/1970'
};
var id = note.id, title = note.title, date = note.date;
console.log(id);
console.log(title);
console.log(date);
/*
Array Destructuring
Array destructuring allows you to create new variables using an array item as a value.
*/
var doj = ['2005', '12', '01'];
var year = doj[0], month = doj[1], day = doj[2];
console.log(year);
console.log(month);
console.log(day);
var yoj = doj[0], dateOfJoining = doj[2];
console.log(yoj);
console.log(dateOfJoining);
