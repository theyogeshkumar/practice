function calculateDiscount(price, discount) {
    if (discount === void 0) { discount = 5; }
    price = price - (price * discount / 100);
    return price;
}
var finalPrice = calculateDiscount(100);
console.log("Final price with default function param");
console.log(finalPrice);
finalPrice = calculateDiscount(100, 10);
console.log("Final price without default function param");
console.log(finalPrice);
