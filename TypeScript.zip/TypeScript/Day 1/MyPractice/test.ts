let x=112;
console.log(x);

let id:number[]=[1,2,3,4,5,6]
console.log(id);

const num:number=123;
console.log(num);

const playercodes ={
    player1:123,
    player2:234,
    player3:345
}
playercodes.player1=123456;
console.log(playercodes.player1);

