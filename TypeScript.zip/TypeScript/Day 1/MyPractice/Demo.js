var fruits;
fruits = ["apple", "banana", "mango"];
for (var index in fruits) {
    console.log(fruits[index]);
}
var id;
id = [1, 2, 3, 4, 5, 6];
for (var number = 0; number < id.length; number++) {
    console.log(id[number]);
}
