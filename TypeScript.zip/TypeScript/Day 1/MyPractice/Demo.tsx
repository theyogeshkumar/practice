let fruits:Array<string>;
fruits=["apple","banana","mango"]
for(var index in fruits){
    console.log(fruits[index]);
}


let id:Array<number>;
id=[1,2,3,4,5,6];
for(var number=0;number<id.length;number++){
    console.log(id[number]);
}