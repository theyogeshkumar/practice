// 1 Create a TyoeScript file and Declare the following variables in that file:
var customerId = 23;
var firstName = "Yogesh";
var lastName = "kumar";
var contactNo = 7011863392;
var email = "mymail@gmail.com";
var isPrevilaged = true;
console.log("Customer Id = " + customerId);
console.log("Name = " + firstName + " " + lastName);
console.log("Contact No. = " + contactNo);
console.log("Email = " + email);
console.log("privilege = " + isPrevilaged);
console.log(customerId + " - " + firstName + " - " + lastName + " - " + contactNo + " - " + email + " - " + isPrevilaged);
console.log();
// 2 Create an array of type any. 
//   Add few numbers, strings and booleans to this array. Display the array members. 
var cars;
cars = ["Hyundai", "Tata", "Mahindra", "Kia", "Toyota", "Mercedes-Benz", "BMW", "Volkswagen"];
console.log("Print Cars in Single line.");
console.log.apply(console, cars);
console.log("Print Cars in next line.");
for (var index = 0; index < cars.length; index++) {
    console.log(cars[index]);
}
console.log();
var any;
any = [1, "shiv", 's', true, 98.87];
console.log.apply(console, any);
console.log();
// 3 Create a function that accepts income and taxRate as parameters and returns the income after tax.
//   taxRate should be 10 percent if user does not specify the same.
function myIncome(income, taxRate) {
    return income - (income * taxRate / 100);
}
var incomeAfterTax = myIncome(45000, 10);
console.log("My income after Tax Deduction is = " + incomeAfterTax);
console.log();
// 4 
function addition() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    var add = 0;
    for (var arg = 0; arg < args.length; arg++) {
        add += args[arg];
    }
    return add;
}
var digits = [2442, 55, 32, 5454];
var add = addition.apply(void 0, digits);
console.log("Addition Using three numbers = " + add);
digits = [100, 95, 37, 2233];
add = addition.apply(void 0, digits);
console.log("Addition Using four numbers = " + add);
console.log();
// 5
var n = 5;
var factorial = function (factNumber) {
    var fact = 1;
    // let number1=7;   
    for (var i = 1; i <= factNumber; i++) {
        fact = fact * i;
    }
    return fact;
};
var fact = factorial(7);
console.log("Factorial of 7 is = " + fact);
