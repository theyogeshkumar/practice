// 1 Create a TyoeScript file and Declare the following variables in that file:
let customerId:number=23;
let firstName:String="Yogesh";
let lastName:String="kumar";
let contactNo:number=7011863392;
let email:string="mymail@gmail.com"
let isPrevilaged:boolean=true;

console.log("Customer Id = "+  customerId);
console.log("Name = "+firstName+" "+lastName);
console.log("Contact No. = "+contactNo);
console.log("Email = "+email);
console.log("privilege = "+isPrevilaged);
console.log(customerId+" - "+firstName+" - "+lastName+" - "+contactNo+" - "+email+" - "+isPrevilaged);
console.log();


// 2 Create an array of type any. 
//   Add few numbers, strings and booleans to this array. Display the array members. 

let cars:Array<string>;
cars=["Hyundai","Tata","Mahindra","Kia","Toyota","Mercedes-Benz","BMW","Volkswagen"]
console.log("Print Cars in Single line.");
console.log(...cars);
console.log("Print Cars in next line.");

for (let index = 0; index < cars.length; index++) {
    console.log(cars[index]);
    
}
console.log();

let any:Array<any>;
any=[1,"shiv",'s',true,98.87]
console.log(...any);
console.log();


// 3 Create a function that accepts income and taxRate as parameters and returns the income after tax.
//   taxRate should be 10 percent if user does not specify the same.

function myIncome(income:number,taxRate:number) {
    return income- (income*taxRate/100);
}
let incomeAfterTax=myIncome(45000,10)

console.log("My income after Tax Deduction is = "+incomeAfterTax);
console.log();


// 4 Create a function named Add. The function should return the sum of all
//  the arguments passed to it. You should be able to call Add function using
//  variable number of arguments. 
// Call the Add function once passing 3 numbers and once passing 4 numbers.

function addition(...args: number[]){
    let add:number = 0;
    for(let arg:number = 0;arg<args.length;arg++) {
        add += args[arg];
    }
    return add;
}

let digits:number[] = [2442,55,32,5454];
let add = addition(...digits);
console.log("Addition Using three numbers = "+add);
digits = [100,95,37,2233];
add = addition(...digits);
console.log("Addition Using four numbers = "+add);
console.log();


// 5) Create an arrow function.
//  The function should accept number as a parameter and return it’s factorial.
let n=5
let factorial = (factNumber:number):number => {

    let fact=1;  
    for(let i=1;i<=factNumber;i++){    
        fact=fact*i;    
    }    
  return fact;
    
}  

let fact=factorial(7)
console.log("Factorial of 7 is = "+fact);


