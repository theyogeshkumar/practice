package com.travel.entity;

import org.springframework.data.repository.CrudRepository;

public interface CountryRepo extends CrudRepository<Country,Integer>{

}
