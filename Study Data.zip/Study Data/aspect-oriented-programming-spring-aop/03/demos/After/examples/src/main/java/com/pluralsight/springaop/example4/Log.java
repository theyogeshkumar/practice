package com.pluralsight.springaop.example4;

public @interface Log {

}
