package com.pluralsight.springaop.example5;

public interface PassengerDao {

	Passenger getPassenger(int id);

}