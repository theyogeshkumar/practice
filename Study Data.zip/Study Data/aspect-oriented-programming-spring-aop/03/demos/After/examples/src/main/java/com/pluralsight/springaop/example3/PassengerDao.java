package com.pluralsight.springaop.example3;

public interface PassengerDao {

	Passenger getPassenger(int id);

}