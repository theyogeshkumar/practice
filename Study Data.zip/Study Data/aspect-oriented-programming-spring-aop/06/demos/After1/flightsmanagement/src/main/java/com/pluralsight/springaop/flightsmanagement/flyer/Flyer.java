package com.pluralsight.springaop.flightsmanagement.flyer;

public interface Flyer {
    void takeOff();
    void fly();
    void land();
}
