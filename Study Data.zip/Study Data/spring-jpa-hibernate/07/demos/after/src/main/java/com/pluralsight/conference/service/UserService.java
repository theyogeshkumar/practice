package com.pluralsight.conference.service;

import com.pluralsight.conference.model.User;

public interface UserService {
    User save(User user);
}
