package com.dao.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.dao.AdminDao;
import com.main.Main;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.pojo.Student;
import com.pojo.Test;

public class AdminImpl implements AdminDao {
	Scanner sc= new Scanner(System.in);
	Test test= new Test();
	Student student= new Student();
	@Override
	public void addQuestion() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
//		sc.nextLine();
		System.out.println("Enter Question:");
		
		test.setQuestion(sc.nextLine());
//		String question;
		
		System.out.println("Enter Answer.");
		test.setAnswer(sc.nextLine());
//		String answer;
		PreparedStatement pstmt=Main.getconnection().prepareStatement("insert into test values(?,?)");
		pstmt.setString(1,test.getQuestion());
		pstmt.setString(2,test.getAnswer());
		pstmt.execute();
		System.out.println("your question is inserted in the table.");
		Main.getconnection().close();
		
	}

	@Override
	public void deleteQuestion() throws ClassNotFoundException, SQLException {
		System.out.println("which Question you want to delete Enter Question Number.");
//		int ques_no;
		test.setQues_no(sc.nextInt());
		
		
		Statement stmt=Main.getconnection().createStatement();
		stmt.execute("delete from test where ques_no="+test.getQues_no()+";");
		System.out.println("your question is now deleted.");
		
		Main.getconnection().close();
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateQuestion() throws SQLException, ClassNotFoundException {
		
		System.out.println("Enter Question number you want to update:");
//		ques_no=sc.nextInt();
		test.setQues_no(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Question.");
//		question=sc.nextLine();
		test.setQuestion(sc.nextLine());
		System.out.println("Enter Answer.");
//		answer=sc.nextLine();
		test.setAnswer(sc.nextLine());
		Statement stmt=Main.getconnection().createStatement();
		stmt.execute("UPDATE test SET question ='"+test.getQuestion()+"' , answer ='"+test.getAnswer()+"' Where ques_no="+test.getQues_no()+";");
		System.out.println("Question and Answer is Updated.");
		Main.getconnection().close();
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Student> allStudent() throws ClassNotFoundException, SQLException, IOException {
		List<Student> list= new ArrayList<Student>();
		
		
	      File myObj = new File("C:\\Yogesh\\result.txt");
	      FileWriter myWriter = new FileWriter("C:\\Yogesh\\result.txt");
	      
	      
	myWriter.write("Record of all students.\n");
	Statement stmt=Main.getconnection().createStatement();
	ResultSet rs=stmt.executeQuery("select roll_no,name,marks from student");
	
	
	
	while(rs.next()) {
		System.out.println(rs.getInt(1)+" - "+rs.getString(2)+" - "+rs.getInt(3));
		myWriter.write(rs.getInt(1)+"  -  "+rs.getString(2)+"  -  "+rs.getInt(3)+"\n");
		Student stud= new Student();
		stud.setRollNo(rs.getInt(1));
		stud.setName(rs.getString(2));
		stud.setMarks(rs.getInt(3));
		list.add(stud);
		
		
	}
	System.out.println("Successfully wrote to the file.");
	myWriter.close();
	Main.getconnection().close();
		// TODO Auto-generated method stub
	
	return list;
		
	}

	@Override
	public void individualReport() throws ClassNotFoundException, SQLException {
		
		System.out.println("Enter Roll Number");
//		int roll_no=sc.nextInt();
		student.setRollNo(sc.nextInt());
		Statement stmt=Main.getconnection().createStatement();
		ResultSet rs=stmt.executeQuery("select roll_no,name,marks from student where roll_no="+student.getRollNo()+";");
		try{
			rs.first();
		}catch(SQLServerException e){
			System.out.println("Enter Correct Roll. Number");
			
		}
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" - "+rs.getString(2)+" - "+rs.getInt(3));
		}
		
		Main.getconnection().close();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void highScorer() throws ClassNotFoundException, SQLException {
		
		Statement stmt=Main.getconnection().createStatement();
		ResultSet rs=stmt.executeQuery("select top 1 roll_no,name,marks from student order by marks desc");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" - "+rs.getString(2)+" - "+rs.getInt(3));
		}
		Main.getconnection().close();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lowScorer() throws SQLException, ClassNotFoundException {
		
		Statement stmt=Main.getconnection().createStatement();
		ResultSet rs=stmt.executeQuery("select top 1 roll_no,name,marks from student order by marks");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" - "+rs.getString(2)+" - "+rs.getInt(3));
		}
		Main.getconnection().close();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addStudent() throws ClassNotFoundException, SQLException {
		
		System.out.println("Enter student name");
//		sc.nextLine();
		student.setName(sc.nextLine());
		System.out.println("Enter Student Marks");
		student.setMarks(sc.nextInt());
		System.out.println("Create Student Username");
		student.setUsername(sc.next());
		System.out.println("Create Student password");
		student.setPassword(sc.next());
		
		Statement stmt=Main.getconnection().createStatement();
//		String query="insert into student values('rahul',80,'rahul','heartbreaker')";
		stmt.execute("insert into student values('"+student.getName()+"',"+student.getMarks()+" ,'"+student.getUsername()+"','"+student.getPassword()+"')");
		
		System.out.println("inserted.");
		Main.getconnection().close();
		// TODO Auto-generated method stub
		
	}

}
