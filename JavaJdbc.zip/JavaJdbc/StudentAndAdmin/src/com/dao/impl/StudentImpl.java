package com.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import com.dao.StudentDao;
import com.main.Main;
import com.pojo.Student;

public class StudentImpl implements StudentDao {

	Scanner sc= new Scanner(System.in);
	@Override
	public void student(ResultSet rs1) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		System.out.println("Test is ready for you.");
		String myAnswer;
		int myMarks = 0;
		Statement stmt=Main.getconnection().createStatement();
		ResultSet rs=stmt.executeQuery("select top 5 question,answer from test");
		int i=1;
		while(rs.next()) {
			
			System.out.println(i+". "+rs.getString(1));
			myAnswer=sc.next();
			if(myAnswer.equals(rs.getString(2))) {
				myMarks+=20;	
			}
			i++;
		}
		System.out.println("your Result is "+myMarks);
		
		if(rs1.next())
			stmt.execute("insert into record values("+rs1.getInt(1)+",'"+rs1.getString(2)+"',"+myMarks+")");
		
		
		
		Main.getconnection().close();
		
	}
	

	
}
