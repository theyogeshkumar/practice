package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.pojo.Student;

public interface StudentDao {


	void student(ResultSet rs1) throws ClassNotFoundException, SQLException;
	
	
}
