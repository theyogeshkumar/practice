package com.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.pojo.Student;

public interface AdminDao {
 void addQuestion() throws ClassNotFoundException, SQLException;
 void deleteQuestion() throws ClassNotFoundException, SQLException;
 void updateQuestion() throws ClassNotFoundException, SQLException;
 List<Student> allStudent() throws ClassNotFoundException, SQLException, IOException;
 void individualReport() throws ClassNotFoundException, SQLException;
 void highScorer() throws ClassNotFoundException, SQLException;
 void lowScorer() throws ClassNotFoundException, SQLException;
 void addStudent() throws ClassNotFoundException, SQLException ;
}
