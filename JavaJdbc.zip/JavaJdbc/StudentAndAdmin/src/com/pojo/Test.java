package com.pojo;

public class Test {

	private int ques_no;
	private String question;
	private String answer;
	public int getQues_no() {
		return ques_no;
	}
	public void setQues_no(int ques_no) {
		this.ques_no = ques_no;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Test(int ques_no, String question, String answer) {
		super();
		this.ques_no = ques_no;
		this.question = question;
		this.answer = answer;
	}
	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
