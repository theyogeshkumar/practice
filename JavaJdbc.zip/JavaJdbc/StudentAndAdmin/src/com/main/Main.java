package com.main;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.dao.impl.AdminImpl;
import com.dao.impl.StudentImpl;
import com.pojo.*;

public class Main {
	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		AdminImpl a= new AdminImpl();
		a.allStudent();
		System.out.println(a.allStudent());
//		login();

	

	}
	
	
	static void login() throws ClassNotFoundException, SQLException, IOException {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter 1 for ADMIN or 2 for STUDENT.");
		int input=sc.nextInt();
		if(input==1) {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=studentManagementSystem;user=sa;password=Password_123");  
			System.out.println("enter username");
			Admin admin=new Admin();
			admin.setUsername(sc.next());
			System.out.println("enter pass");
			admin.setPassword(sc.next());
			
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from admin where username='"+admin.getUsername()+"' and password='"+admin.getPassword()+"';");
			if(rs.next()) {
				System.out.println("login sucessfull.");
				admin();
			}else {
				System.out.println("invalid username or password");
			}
			
			
			
		}else if(input==2) {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=studentManagementSystem;user=sa;password=Password_123");  
			System.out.println("login to get the Test");
			System.out.println("enter username");
			Student student=new Student();
			student.setUsername(sc.next());
//			String username=sc.next();
			System.out.println("enter pass");
//			String password=sc.next();
			student.setPassword(sc.next());
			Statement stmt1=con.createStatement();
			
			ResultSet rs1=stmt1.executeQuery("select roll_no,name from student where username='"+student.getUsername()+"';" );
			
			
			Statement stmt=con.createStatement();
			
			
			ResultSet rs=stmt.executeQuery("select * from student where username='"+student.getUsername()+"' and password='"+student.getPassword()+"';");
			if(rs.next()) {
				System.out.println("login sucessfull.");
//				student(rs1);
				StudentImpl student1= new StudentImpl();
				student1.student(rs1);
			}else {
				System.out.println("invalid username or password");
				login();
			}
			
		}else {
			System.out.println("Enter Correct Input.");
			login();
		}
		
	}
	
	static void admin() throws ClassNotFoundException, SQLException, IOException{
		System.out.println("Enter the given key to perform asmin task.");
		System.out.println("1. Add questions.");
		System.out.println("2. Delete question.");
		System.out.println("3. Update Question.");
		System.out.println("4. Report Card of all student");
		System.out.println("5. Report card of individual student by roll no.");
		System.out.println("6. Highest Scorer");
		System.out.println("7. Lowest Scorer");
		System.out.println("8. Add Student");
		int key=sc.nextInt();
		Test test= new Test();
		Student student=new Student();
		AdminImpl adminDao=new AdminImpl();
		switch (key) {
		case 1:
			adminDao.addQuestion();
			admin();
			break;
			
		case 2:
			adminDao.deleteQuestion();
			admin();
			break;
		
		case 3:
			adminDao.updateQuestion();
			admin();
			break;
		
		case 4:
			
			adminDao.allStudent();
			admin();
			break;
		
		case 5:
			adminDao.individualReport();
			admin();
			break;
			
		case 6:
			adminDao.highScorer();
			admin();
			break;
			
		case 7:
			adminDao.lowScorer();
			admin();
			break;
			
		case 8:
			adminDao.addStudent();
			admin();
			break;
			
		default:
			System.out.println("Wrong Input Please try Again");
			admin();
			break;
		}
		
	}
	
	
	public static Connection getconnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=studentManagementSystem;user=sa;password=Password_123");
		return con;
	}
	

	

}
