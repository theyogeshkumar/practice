
create database studentManagementSystem
use studentManagementSystem

create table student(
roll_no int primary Key identity(1,1),
name varchar(30) not null,
marks int not null,
username varchar(50) not null unique,
password varchar(50) not null,
)
drop table student

select * from student

create table admin(
username varchar(50) primary key,
password varchar(50) not null unique
)
select * from admin
insert into admin values('s','p')

select username,password from admin where username='sonusisodia' and password='password'

create table test(
ques_no int  primary key Identity(1,1),
question varchar(200) not null,
answer varchar(500) not null,
)

select * from test
drop table test
insert into test values('145-19',126)
delete from test where ques_no=15
UPDATE test
SET question = 'java', answer = 'lang'
WHERE ques_no=12;

select top 1 roll_no,name,marks from student 
order by marks

insert into student values('Avinash Singh',90,'avi','avi')
select * from student where marks
select top 5 question from test
select * from student

create table record(
roll_no int,
name varchar(30),
marks int
)
drop table record
select * from record
select * from student