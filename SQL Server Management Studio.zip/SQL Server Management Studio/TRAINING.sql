--Day2 
USE ADVENTUREWORKS2019
--1
Select  BusinessEntityID,FirstName,MiddleName,LastName, ModifiedDate
From Person.Person
Where ModifiedDate>'2000-dec-29'

--2
Select  BusinessEntityID,FirstName,MiddleName,LastName, ModifiedDate
From Person.Person
Where ModifiedDate NOT Between '2009-dec-1' And '2010-dec-31'
order by ModifiedDate

--3
SELECT ProductID,Name
FROM Production.Product
Where Name like 'chain%'

--4
Select  BusinessEntityID,FirstName,MiddleName,LastName
From Person.Person
Where  MiddleName IN ('E','B')

--5
SELECT SalesOrderID,OrderDate,TotalDue FROM Sales.SalesOrderHeader
WHERE OrderDate BETWEEN '1-sep-2011' AND '30-sep-2011' AND TotalDue>1000

--6
SELECT TotalDue,TerritoryID,SalesPersonID FROM Sales.SalesOrderHeader
WHERE TotalDue>1000 AND SalesPersonID=279 or TerritoryID=6

--7
SELECT ProductID,Name,Color from Production.Product
Where Color!='blue'

--8
SELECT BusinessEntityID,FirstName, MiddleName,LastName from Person.Person
order By LastName,FirstName,MiddleName

--9
SELECT CONCAT(AddressLine1,' (',PostalCode,')')  as House_Address  FROM Person.Address

--10
SELECT ProductID, ISNull (color, 'No Color') AS Color,Name from Production.Product

--11
SELECT ProductID, isNull (color, 'No Color') as Colour,Name , Concat(Name,':',isNull (color, 'No Color')) AS Description  from Production.Product


--12
select SpecialOfferID,Description,MaxQty, MinQty, MaxQty-MinQty as Difference from Sales.SpecialOffer

--13
select SpecialOfferID,Description,DiscountPct,isNull(MaxQty,10)*DiscountPct AS NewDiscount from Sales.SpecialOffer

--14
SELECT substring(AddressLine1,1,10) as Address  FROM Person.Address

--15
select SalesOrderID,OrderDate,ShipDate, DATEDIFF(day,OrderDate,ShipDate) AS NumberOfDays from Sales.SalesOrderHeader

--16
select convert(varchar(10), OrderDate, 120)AS OrderDate, convert(varchar(10), ShipDate, 120)AS ShipDate   from Sales.SalesOrderHeader

--17
select SalesOrderID,DATEADD(MONTH,6,OrderDate) AS OrderDateSixMonthAdded   from Sales.SalesOrderHeader

--18
select SalesOrderID, Year(OrderDate) AS YearOfOrderDate, MONTH(OrderDate) AS MonthOfOrderDate, convert(varchar(10),OrderDate,120) AS OrderDate
from Sales.SalesOrderHeader

--19
Select FLOOR(RAND()*10+1);

--20
select SalesOrderID,OrderDate
from Sales.SalesOrderHeader
Where OrderDate  Between '2011-jan-01' AND '2011-dec-31'

--21
select  Month(OrderDate) AS MonthOfOrderDate,Year(OrderDate) AS YearOfOrderDate,SalesOrderID,OrderDate
from Sales.SalesOrderHeader

--DAY 3
--1
Select Count(CustomerID) AS NumberOfCustomers from Sales.Customer

--2
Select AVG(ListPrice) AS Average,MAX(ListPrice) AS MaxPrice ,Min(ListPrice) AS MinPrice from Production.Product

--3
select  ProductID,sum(OrderQty) AS OrderTotalPerProduct  from Sales.SalesOrderDetail
group By ProductID
Order By ProductID

--4
select  SalesOrderID,sum(LineTotal) AS TotalLine  from Sales.SalesOrderDetail
group By SalesOrderID

--5
select  ProductLine,Count(ProductLine) AS TotalLine  from Production.Product
GROUP BY ProductLine

--6
select salesOrderID
from Sales.SalesOrderDetail
Group by SalesOrderID
having sum(lineTotal)>1000


--7
select  SalesOrderID,sum(LineTotal) AS TotalLine  from Sales.SalesOrderDetail
group By SalesOrderID
Having Sum(LineTotal)>1000

--8
select ProductModelID,count(ProductModelID) AS One from Production.Product
group by ProductModelID
Having count(ProductModelID) =1


--9

select SalesOrderDetail.ProductID from Sales.SalesOrderHeader,Sales.SalesOrderDetail,Production.Product


--10 --study that point again
SELECT * FROM ( SELECT ROW_NUMBER() OVER (ORDER BY HireDate) AS row_num
             , HireDate,NationalIDNumber,JobTitle
  FROM HumanResources.Employee
) AS sub
WHERE row_num = 3



--11 Display the customer who has placed 2nd highest orders
SELECT * FROM Sales.SalesOrderDetail
Order bY OrderQty Desc
OFFSET 1 rOW
fetch next 1 ROW ONly

--12  Display top 25% of costliest products in every subcategory.
Select TOP 25 PERCENT
ListPrice,Name,ProductSubcategoryID
from Production.Product
Order By ListPrice Desc


-- 13 Create a sequence to be used in two different temporary tables (Note: create temporary tables if required) 


--Day 4
--1
Select JobTitle,BirthDate,FirstName,lastName 
from HumanResources.Employee
Inner Join Person.Person on HumanResources.Employee.BusinessEntityID=Person.Person.BusinessEntityID

--2
Select CustomerId,StoreID,TerritoryID,FirstName,LastName
From Sales.Customer
Inner Join Person.Person On Sales.Customer.CustomerID=Person.Person.BusinessEntityID


--3

Select salesOrderId,SalesQuota,Bonus 
from Sales.SalesPerson
Inner Join Sales.SalesOrderHeader On Sales.SalesPerson.BusinessEntityID=SalesOrderHeader.SalesPersonID


--4
Select Color,Size,CatalogDescription
From Production.Product
Inner Join Production.ProductModel On Production.Product.ProductModelID=Production.ProductModel.ProductModelID

--5  Write a query that displays the names of the customers along with the product names that they have purchased. 
--Hint: Five tables will be required to write this query!

Select SalesOrderId,Name 
from Sales.SalesOrderDetail
Inner Join Production.Product On Production.Product.ProductID=Sales.SalesOrderDetail.ProductID

Select * from Production.Product
select * from Sales.SalesOrderDetail

--6   Write a query that displays all the products along with the SalesOrderID
--    even if an order has never been placed for that product. 
--    Join to the Sales.SalesOrderDetail table using the ProductID column.


select SalesOrderID,Product.Name from Sales.SalesOrderDetail
Inner join Production.Product
ON SalesOrderDetail.ProductID=Product.ProductID

select * from Sales.SalesOrderDetail
Inner join Production.Product
ON SalesOrderDetail.ProductID=Product.ProductID


--7  The Sales.SalesOrderHeader table contains foreign keys to the Sales.CurrencyRate and Purchasing.ShipMethod tables.
--Write a query joining all three tables, making sure it contains all rows from Sales.SalesOrderHeader.
--Include the CurrencyRateID, AverageRate, SalesOrderID, and ShipBase columns.

	SELECT ROW_NUMBER() OVER(ORDER BY SalesOrderId ASC) AS RowNu
	,SalesOrderID,RevisionNumber,OrderDate,DueDate,ShipDate,Status,OnlineOrderFlag,
	SalesOrderNumber,PurchaseOrderNumber,AccountNumber
	,CustomerID,SalesPersonID,TerritoryID,BillToAddressID,ShipToAddressID
	,salesOrderHeader.ShipMethodID,CreditCardID,CreditCardApprovalCode,Sales.SalesOrderHeader.CurrencyRateID,
	SubTotal,TaxAmt,Freight,TotalDue,Comment,SalesOrderHeader.rowguid,SalesOrderHeader.ModifiedDate
	,SalesOrderID,ShipBase,Sales.CurrencyRate.CurrencyRateID AS CurrencyRateIDFromCurrency,Sales.CurrencyRate.AverageRate
	FROM Sales.SalesOrderHeader 
	LEFT JOIN Purchasing.ShipMethod
	ON Purchasing.ShipMethod.ShipMethodID=Sales.SalesOrderHeader.ShipMethodID
	Left JOIN Sales.CurrencyRate
    ON sales.SalesOrderHeader.CurrencyRateID=Sales.CurrencyRate.CurrencyRateID ;

--8 DO

Select SalesOrderID,SalesOrderNumber,OrderDate,ShipDate from Sales.SalesOrderHeader

SELECT * FROM Sales.SalesOrderHeader
SELECT * from sales.Customer
select * from person.person
Select * from Production.Product
Select * from Production.ProductCategory
select * from Production.ProductSubcategory
select * from Sales.SalesTerritory
select * from Sales.CountryRegionCurrency

Select SalesOrderID,SalesOrderNumber,OrderDate,ShipDate,Sales.SalesTerritory.Name from Sales.SalesOrderHeader
left Join sales.Customer
On Sales.SalesOrderHeader.CustomerID=Sales.Customer.CustomerID

Left join sales.SalesTerritory
On Sales.Customer.TerritoryID=Sales.SalesTerritory.TerritoryID

Select * from Sales.SalesOrderHeader

left Join sales.Customer
On Sales.SalesOrderHeader.CustomerID=Sales.Customer.CustomerID



--
Select Production.Product.Name,ProductCategory.Name AS CategoryName,ProductSubcategory.Name AS SubCategoryname 
from Production.ProductCategory
left Join Production.ProductSubcategory
On Production.ProductCategory.ProductCategoryID =ProductCategory.ProductCategoryID

Right Join Production.Product
On Production.Product.ProductSubcategoryID=ProductSubcategory.ProductSubcategoryID



--9
Select Top 1 * from HumanResources.Employee
Order By BirthDate 

--10 Do


Select * from Production.Product

select * from Production.ProductModel
select * from sales.SalesPersonQuotaHistory
select * from Person.person




--prac
select  FirstName,LastName from Person.Person
Group By Firstname
order By FirstName


--day 6
--1.	Create a Function to check and print all the prime numbers between a range defined by user.

DECLARE @I INT=2
DECLARE @PRIME INT=0
DECLARE @OUTPUT TABLE (NUM INT)
WHILE @I<=100
BEGIN
    DECLARE @J INT = @I-1
    SET @PRIME=1
    WHILE @J>1
    BEGIN
        IF @I % @J=0
        BEGIN
            SET @PRIME=0
        END
        SET @J=@J-1
    END
    IF @PRIME =1
    BEGIN
        INSERT @OUTPUT VALUES (@I)
    END
    SET @I=@I+1
END
select * from @OUTPUT

-------------------------
--MY PRACTICE AREA
SELECT Color , count(color) as num FROM Production.Product
group by color	


Select  BusinessEntityID,FirstName,MiddleName,LastName, ModifiedDate
From Person.Person
Where ModifiedDate NOT Between '2013-dec-1' And '2013-dec-31'
order by ModifiedDate


Select  BusinessEntityID,FirstName,MiddleName,LastName, ModifiedDate
From Person.Person
Where not( ModifiedDate > '2013-dec-1' And ModifiedDate < '2013-dec-31')
order by ModifiedDate

Select *
From Person.Person
where BusinessEntityID>5 And BusinessEntityID<10
-------------------
---------------------------