use AdventureWorks2019

select * from Person.Person
where PersonType='Em' And (Title='Mr.' OR Title='Ms.')	

select * from Person.Person
Where Title IS  Null

select * from Person.Person
Where FirstName like 'D%on'

select * from Person.Person
Where FirstName like 'D[a-h]%n'


Select ProductID,Name,ProductNumber,Color,StandardCost,ProductSubcategoryID From Production.Product
Where StandardCost>500 AND StandardCost<1500
--or
Select ProductID,Name,ProductNumber,Color,StandardCost,ProductSubcategoryID From Production.Product
Where StandardCost BETWEEN 500 AND 1500

-------------------------------------------

Select BusinessEntityID,NationalIDNumber,JobTitle,BirthDate,MaritalStatus,Gender,HireDate
From HumanResources.Employee
Where YEAR(BirthDate)=1974
--or
Select BusinessEntityID,NationalIDNumber,JobTitle,BirthDate,MaritalStatus,Gender,HireDate
From HumanResources.Employee
Where BirthDate Like '1974%' AND Gender='F'


--
select ProductID,Name,ProductNumber,
CASE 
	When Color = 'Green' Then 'G'
	When Color = 'Black' Then 'B'
	When Color = 'Yellow' Then 'Y'
	When Color = 'Silver' Then 'S'
	Else 'NA'
END AS Colour,
StandardCost,ProductSubCategoryID
from Production.Product

select ProductID,Name,ProductNumber,Color,
ROUND(StandardCost,2) AS [Standard Cost],ProductSubCategoryID
from Production.Product

select ABS(-123)