use YogeshSisodia

select * into student_copy_details
from studentManagementSystem.dbo.student
select * from student_copy_details

--altering the table
--adding column in a table
alter table student_copy_details
add mother_name varchar(40)

alter table student_copy_details
add phone_no varchar(10) null

insert into student_copy_details
values('Rahul',85,'rahul','heatbreaker','hero','heroin','90887654') 
where roll_no=1


update student_copy_details
set father_name = 'pita ji', mother_name='mata ji',phone_no='9865352837'
where roll_no=2
select * from student_copy_details

delete from student_copy_details where roll_no=6
--
alter table student_copy_details
delete mother_name

insert into student_copy_details values('ghanendra',85,'ghan','nendra','bapu ji','mai','9234567891')
select * from student_copy_details

alter table student_copy_details
add constraint cons unique(username)
use studentManagementSystem
select * from student
select * from record
select * from student
ORDER BY roll_no
OFFSET 1 ROW
FETCH first 2 row ONLY
use YogeshSisodia
create schema sales
DROP SCHEMA SALES
create table sales.terrritory(
territoryId int primary key,
territory_name varchar(30),
country_id int
)
DROP TABLE sales.terrritory
select * from SALES.terrritory
select GETDATE()