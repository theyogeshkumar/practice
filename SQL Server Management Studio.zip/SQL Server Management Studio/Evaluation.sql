use AdventureWorks2019
select * from Person.PersonPhone
select * from Person.PhoneNumberType
select * from Person.Person
select * from Person.AddressType
select * from Person.Address

select PhoneNumber from Person.PersonPhone
where PhoneNumberTypeID=1

select PhoneNumberTypeID from Person.PhoneNumberType


select PhoneNumber from Person.PersonPhone
where PhoneNumberTypeID IN (select PhoneNumberTypeID from Person.PhoneNumberType WHERE PhoneNumberTypeID=1)

select PhoneNumberTypeID from Person.PhoneNumberType



select PhoneNumber from Person.PersonPhone
where PhoneNumberTypeID= (select PhoneNumberTypeID from Person.PhoneNumberType
where Name='Cell')

select PhoneNumberTypeID from Person.PhoneNumberType
where Name='Cell'
--1
select Person.PersonPhone.PhoneNumber from Person.PersonPhone
inner join Person.PhoneNumberType
on Person.PersonPhone.PhoneNumberTypeID=Person.PhoneNumberType.PhoneNumberTypeID
where Person.PersonPhone.PhoneNumberTypeID=1

select * from Person.PersonPhone
inner join Person.PhoneNumberType
on Person.PersonPhone.PhoneNumberTypeID=Person.PhoneNumberType.PhoneNumberTypeID
where Person.PersonPhone.PhoneNumberTypeID=1

--rank all the person as per the modified date 
--2
select ROW_NUmber() over (Order by ModifiedDate)  AS RANK, ModifiedDate,FirstName,MiddleName,LastName 
from Person.Person

---




select * from Person.Person
select ROW_NUmber() over (Order by ModifiedDate)  AS RANK, ModifiedDate,FirstName,MiddleName,LastName 
from Person.Person


--name, email, phone number employee may include anything

select * from person.Person
select * from person.EmailAddress
select * from HumanResources.Employee

--3
select Person.BusinessEntityID,LoginID,JobTitle,HireDate,FirstName,MiddleName,LastName,EmailAddress.EmailAddress,PersonPhone.PhoneNumber from Person.Person
left Join Person.EmailAddress
ON Person.EmailAddress.BusinessEntityID= Person.Person.BusinessEntityID
left join HumanResources.Employee
ON
Person.BusinessEntityID=HumanResources.Employee.BusinessEntityID
left join Person.PersonPhone
ON Person.BusinessEntityID=PersonPhone.BusinessEntityID
order by Person.BusinessEntityID


