--Try

Create DataBase SonuSisodia;
use Sonusisodia;

Create table MyTable(
 ProductId int primary Key ,
 ProductName varchar(100),
 Price int,
 ProductDesc varchar(100)
 )

 declare @Start int
 set @Start=1

 Declare @Name varchar(100)
 Declare @Description varchar(100)

 While(@start<=100)
 Begin 
	set @Name='Product Name - '+LTrim(@Start)
	set @Description='Product Desc - '+LTrim(@Start)
	Insert into MyTable values(@start,@Name,@Start*10,@Description)
	Set @Start=@Start+1
 End

 Select * from MyTable

 Select * from MyTable
 ORder By Price
 Offset 0 Rows
 Fetch Next 21 Rows ONly