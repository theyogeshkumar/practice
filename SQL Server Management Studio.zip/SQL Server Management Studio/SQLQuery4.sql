--plsql
--demo anonymous block:declare and assign value to variabless

DECLARE @username Varchar(50)
Set @username='Sonu Sisodia'
DECLARE @DOB DATE='12-Jan-2000'
SELECT @username

PRINT @username
--get product name id in a varible
DECLARE @pid INT =317
DECLARE @prodname varchar(300)
SELECT @prodname= Name FROM AdventureWorks2019.Production.Product
Where ProductID=@pid

Print 'Prod name '+ @prodname
Print concat( 'Pid ', @pid)

--anonymous block if else
--check number is negative or positive;

declare @num int =-12
if @num>0
	begin
	print 'positive'
	print 'best part'
	end
else
begin
	print 'negative;'
	print 'hello'
	print 'bye'
	end

--anonymous block if else if
--check number is negative or positive;

declare @colr varchar(20)
Set @colr='rebad'
if UPPER(@colr)='RED'
print 'red is a bright color'
else if Upper(@colr)='Green'
print 'Green is a bright color'
else
print 'black is a not bright color'


--loops
declare @num Int
set @num =1
While (@num<=10)
begin
print 'hello'
print @num
SET @num =@num+1
end



------------------------------------
--
Select ProductID, color from Production.Product

create table #red(
ProductId Int,
Name varchar(100),
Color varchar(50)
);
create table #black(
ProductId Int,
Name varchar(100),
Color varchar(50)
);
create table #other(
ProductId Int,
Name varchar(100),
Color varchar(50)
);
declare @prdid int=317
declare @prdname varchar(100)
declare @prdcolor varchar(50)

Select @prdid=ProductID,@prdname= Name,@prdcolor= Color From Production.Product
Where Color='red'
if Upper(@prdcolor)='RED'
begin
	insert into #red values (@prdid,@prdname,@prdcolor)
end
if Upper(@prdcolor)='BLACK'
begin
	insert into #black values (@prdid,@prdname,@prdcolor)
end
if Upper(@prdcolor)='OTHER'
begin
	insert into #other values (@prdid,@prdname,@prdcolor)
end

select * from #red