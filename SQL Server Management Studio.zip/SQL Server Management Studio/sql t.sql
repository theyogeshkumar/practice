--create database
create database YogeshSisodia

--using the same database
use YogeshSisodia

--create table
create Table Family(
position int primary Key,
name Varchar(30),
work varchar(30)
)

--insert values into table
insert into Family   values(6,'elder_brother_4','entreprenure')
select * from Family

--upadate the values in specific column
UPDATE Family
SET relation = 'mother'
WHERE position=2;

--alter column
alter table Family 
alter column relation Varchar(100) ;

-- create table
create table student(
roll_no int primary key,
student_name varchar(30),
marks int not null
)

--select all data from table
select * from student

--insert into table
insert into student values(4,'Jitender',50)

--update specific column attribute(values)
Update  student set student_name='Yogesh' where roll_no=1 

--update all column attributes(values)
Update  student set marks=marks-10

--delete row from student
delete from student 
where roll_no=2

--select query accordingly using where clause and order by
select * from student
where marks=90
order by student_name DESC

select student_name from student

--to count the no of rows in column. its not include null_values
select count (fatherName) from student


select Avg(marks) from student
select MAX(marks) from student
select MIN(marks) from student

--select query with another select query
select * from student
where marks=(
select marks=min(marks) from student
)

select ABS(marks) from  student
--abs return negative to positive number
select ABS(-900)
--it return ceil value 1901
select CEILING(1900.0003)
--it return floor value 1900
select FLOOR(1900.99)

--return that number is negative positive or zero
select sign(10.20),SIGN(-100),SIGN(900.23),SIGN(0),SIGN(-0)

--square of the number
select SQUARE(3)
--sruareroot of the number
select SQRT(625)

--some math functions
select PI(),cos(0),SIN(0),tan(0)
select EXP(1)

--string operation 
--it gives length of the string
select student_name,LEN(student_name) from student
--return uppercase characters
select student_name,Upper(student_name) AS Capital_letters from student
--return lowwercase characters
select student_name,Lower(student_name)AS Small_letters from student
--trim blank spaces from right or left side
select LTRIM('     hello my wordl  ');
select RTRIM('hello woersd    '),len('hello woersd    ');
select SUBSTRING('MICROSOFT',1,5);
select REPLACE('MICROSOFT','MIC','MAJ');


--to get the current date
select getDate()
select SYSDATETIME()
select SYSDATETIMEOFFSET()

select datename(WEEKDAY,'1998-06-10 15:8:8.08')
select DATENAME(WEEKDAY,CURRENT_TIMESTAMP);
select CURRENT_TIMESTAMP
SELECT DATEDIFF(YEAR,'1998-06-10',CURRENT_TIMESTAMP);
SELECT DATEDIFF(DAY,'1998-06-10',CURRENT_TIMESTAMP);
SELECT DATEDIFF(HOUR,'1998-06-27',CURRENT_TIMESTAMP);



select * from family
select * from student
select * from student_copy_details
--add column
alter table student 
add fatherName varchar(30)

--modify column
alter table student 
alter column fatherName varchar(50) 

alter table student 
alter column fatherName varchar(50) 

--update value in specific column
update student  set fatherName='daddy', student_name='Saurabh'
where marks=80

--drop column from the table
alter table student 
drop column fatherName

--rename the table name by using the stored procedure in the sql server.
Exec sp_rename 'student', 'student_details'

--truncate table
truncate table student_details

--drop table
drop table #temp


--temperory tables in sql server
--direct copy into new tables
select *
into #temptable
from student

-- second is to create temp table then insert --
create table #temp(
roll_no int primary key,
stud_name varchar(20)
)
--then insert
insert into #temp
select roll_no,student_name
from student
where roll_no=4


--select into
select *
into table1
from student
where student_name='jitender'

--check constraint
create table products(
prod_id int primary key,
prod_name varchar(20),
prod_price int check(prod_price>20)
)


insert into products values (4,'chocolate',100)
select * from products
drop table #temp

create table lepcha(
eid int primary key,
e_name varchar(30) not null,
salary money not null,
designtion varchar (20) not null
)

select * from lepcha

insert into lepcha values(1,'satish',12000,'TSE')

go
insert into lepcha values(2,'satish',12000,'TSE','skky')
insert into lepcha values(3,'satish',12000,'TSE','avicore')
insert into lepcha values(4,'satish',12000,'TSE','press')
insert into lepcha values(5,'satish',12000,'TSE','mongo')
go


alter table lepcha 
add  project_name varchar(30) null constraint Not_Null unique

update lepcha set project_name='data' from lepcha
where eid=1

alter table lepcha
drop column project_name

alter table lepcha drop constraint Not_Null,  column project_name

alter table lepcha alter column  project_name varchar(100)



--alias
select project_name as project,eid from lepcha
select eid 'Employee id' from lepcha



---
---
---
---
---
---
---
---

Declare @var int 
set @var=1

while @var<=100
begin
print @var
set @var=@var+1
end