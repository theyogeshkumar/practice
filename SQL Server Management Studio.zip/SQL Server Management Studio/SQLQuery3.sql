Create Database JavaJdbc
use JavaJdbc
create table Student(
StudentId int  Not Null Primary key,
Name varchar(100) Not Null,
Class Int 
)

select * from Student

insert into Student values(1,'Yogesh kumar',12)